import * as i0 from '@angular/core';
import { signal, computed, Injectable, inject, EventEmitter, Output, Input, Component, HostListener, ViewChild } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

const COHORT_WIDTH = 180;
const COHORT_EXPANDED_WIDTH = 280;
const COHORT_HEIGHT = 50;
const COHORT_EXPANDED_HEIGHT = 54;
const DEPENDENCY_WIDTH = 46;
const DEPENDENCY_HEIGHT = 46;
class CohortDesignerService {
    nodes = signal([]);
    connections = signal([]);
    selectedNodeId = signal(null);
    selectedConnectionId = signal(null);
    activeConnecting = signal(null);
    transform = signal({ zoom: 1, panX: 0, panY: 0 });
    hoveredPort = signal(null);
    // Right sidebar panel state
    isRightPanelOpen = signal(false);
    rightPanelTab = signal('overview');
    allBlocksSection = signal('cohorts');
    selectedNode = computed(() => {
        const id = this.selectedNodeId();
        if (!id)
            return null;
        return this.nodes().find(n => n.id === id) || null;
    });
    selectedConnection = computed(() => {
        const id = this.selectedConnectionId();
        if (!id)
            return null;
        return this.connections().find(c => c.id === id) || null;
    });
    // Sorted in sequence from left to right as displayed on the canvas
    cohortNodes = computed(() => {
        return this.nodes().filter(n => n.type === 'cohort')
            .slice()
            .sort((a, b) => a.x - b.x || a.y - b.y);
    });
    dependencyNodes = computed(() => {
        return this.nodes().filter(n => n.type === 'dependency')
            .slice()
            .sort((a, b) => a.x - b.x || a.y - b.y);
    });
    // Calculate coordinates for Left (in) and Right (out) ports taking custom width/height into account
    getPortCoordinates(nodeId, port) {
        const node = this.nodes().find(n => n.id === nodeId);
        if (!node)
            return { x: 0, y: 0 };
        const isCohort = node.type === 'cohort';
        const cNode = isCohort ? node : null;
        const isExpanded = isCohort && !!cNode?.isExpanded;
        const width = isCohort
            ? (cNode?.width || (isExpanded ? COHORT_EXPANDED_WIDTH : COHORT_WIDTH))
            : DEPENDENCY_WIDTH;
        const height = isCohort
            ? (cNode?.height || (isExpanded ? COHORT_EXPANDED_HEIGHT : COHORT_HEIGHT))
            : DEPENDENCY_HEIGHT;
        if (port === 'left') {
            return { x: node.x, y: node.y + height / 2 };
        }
        else {
            return { x: node.x + width, y: node.y + height / 2 };
        }
    }
    calculateBezierPath(x1, y1, fromPort, x2, y2, toPort) {
        const dx = Math.abs(x2 - x1);
        const offset = Math.max(30, Math.min(140, dx * 0.5));
        const cx1 = fromPort === 'right' ? x1 + offset : x1 - offset;
        const cy1 = y1;
        const cx2 = toPort === 'left' ? x2 - offset : x2 + offset;
        const cy2 = y2;
        return `M ${x1} ${y1} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x2} ${y2}`;
    }
    // --- Graph Traversal & Cycle Detection ---
    /**
     * Check if a directed path already exists from startNodeId to targetNodeId.
     */
    hasPath(startNodeId, targetNodeId) {
        if (startNodeId === targetNodeId)
            return true;
        const visited = new Set();
        const queue = [startNodeId];
        visited.add(startNodeId);
        while (queue.length > 0) {
            const current = queue.shift();
            if (current === targetNodeId)
                return true;
            const downstream = this.connections()
                .filter(c => c.fromNodeId === current)
                .map(c => c.toNodeId);
            for (const next of downstream) {
                if (!visited.has(next)) {
                    visited.add(next);
                    queue.push(next);
                }
            }
        }
        return false;
    }
    /**
     * Validate if toNodeId is an allowable target for the active connection.
     * Rules:
     * 1. Cannot connect Cohort directly to Cohort (must have a dependency in between).
     * 2. Cannot connect Dependency directly to Dependency.
     * 3. Cannot connect a node to itself.
     * 4. Cannot create circular dependencies (cycles).
     */
    isValidTarget(toNodeId) {
        const active = this.activeConnecting();
        if (!active)
            return false;
        if (active.fromNodeId === toNodeId)
            return false;
        const fromNode = this.nodes().find(n => n.id === active.fromNodeId);
        const toNode = this.nodes().find(n => n.id === toNodeId);
        if (!fromNode || !toNode)
            return false;
        // Rule 1: No direct Cohort-to-Cohort connection
        if (fromNode.type === 'cohort' && toNode.type === 'cohort') {
            return false;
        }
        // Rule 2: No direct Dependency-to-Dependency connection
        if (fromNode.type === 'dependency' && toNode.type === 'dependency') {
            return false;
        }
        // Rule 3: No circular dependencies (cycles)
        // If a path already exists from toNodeId to active.fromNodeId, adding this edge would create a cycle!
        if (this.hasPath(toNodeId, active.fromNodeId)) {
            return false;
        }
        return true;
    }
    // --- Adding Nodes ---
    addCohort(nameOrX, subjectsOrY, customData) {
        const cohorts = this.cohortNodes();
        const letter = String.fromCharCode(65 + (cohorts.length % 26)); // A, B, C...
        const { panX, panY, zoom } = this.transform();
        let name = `Cohort ${letter}`;
        let subjects = 20;
        let spawnX;
        let spawnY;
        if (typeof nameOrX === 'string') {
            name = nameOrX;
            const targetVal = customData?.randomizationTarget ?? customData?.subjects ?? 20;
            subjects = typeof subjectsOrY === 'number' ? subjectsOrY : targetVal;
            spawnX = customData?.x !== undefined ? customData.x : (-panX + 80 + (cohorts.length * 60)) / zoom;
            spawnY = customData?.y !== undefined ? customData.y : (-panY + 180 + (cohorts.length * 30)) / zoom;
        }
        else {
            spawnX = nameOrX !== undefined ? nameOrX : (-panX + 200 + (cohorts.length * 40)) / zoom;
            spawnY = subjectsOrY !== undefined ? subjectsOrY : (-panY + 180 + (cohorts.length * 30)) / zoom;
            name = customData?.name || `Cohort ${letter}`;
            const targetVal = customData?.randomizationTarget ?? customData?.subjects ?? 20;
            subjects = customData?.subjects !== undefined ? customData.subjects : targetVal;
        }
        const newCohort = {
            id: customData?.id || `cohort-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            type: 'cohort',
            x: Math.round(spawnX),
            y: Math.round(spawnY),
            name: customData?.name || name,
            subjects: subjects,
            cohortLevel: customData?.cohortLevel || 'Worldwide',
            randomizationTarget: customData?.randomizationTarget ?? subjects,
            targetLastSubjectRandomized: customData?.targetLastSubjectRandomized || '',
            screeningPeriod: customData?.screeningPeriod ?? 14,
            color: customData?.color || '#000000', // Default back to black color
            description: customData?.description || '',
            width: customData?.width,
            height: customData?.height,
            isExpanded: false
        };
        this.nodes.update(nodes => [...nodes, newCohort]);
        this.allBlocksSection.set('cohorts');
        this.selectNode(newCohort.id);
        return newCohort;
    }
    addCohortByName(name, data) {
        return this.addCohort(name, data?.subjects, data);
    }
    addCohorts(items) {
        const created = [];
        for (const item of items) {
            if (typeof item === 'string') {
                created.push(this.addCohortByName(item));
            }
            else {
                created.push(this.addCohort(item.x, item.y, item));
            }
        }
        return created;
    }
    toggleCohortExpand(nodeId) {
        const node = this.nodes().find(n => n.id === nodeId);
        if (!node || node.type !== 'cohort')
            return;
        const current = !!node.isExpanded;
        this.updateNodeData(nodeId, { isExpanded: !current });
    }
    updateNodeDimensions(id, width, height, x, y) {
        this.nodes.update(nodes => nodes.map(node => {
            if (node.id === id && node.type === 'cohort') {
                const updated = {
                    ...node,
                    width,
                    height
                };
                if (x !== undefined)
                    updated.x = x;
                if (y !== undefined)
                    updated.y = y;
                return updated;
            }
            return node;
        }));
    }
    resetCohortDimensions(id) {
        this.nodes.update(nodes => nodes.map(node => {
            if (node.id === id && node.type === 'cohort') {
                const { width, height, ...rest } = node;
                return {
                    ...rest,
                    width: COHORT_WIDTH,
                    height: COHORT_HEIGHT,
                    isExpanded: false
                };
            }
            return node;
        }));
    }
    addDependency(x, y, customDataOrIcon) {
        const deps = this.dependencyNodes();
        const count = deps.length + 1;
        const customData = typeof customDataOrIcon === 'object' ? customDataOrIcon : undefined;
        const icon = typeof customDataOrIcon === 'string' ? customDataOrIcon : (customData?.icon || 'clock');
        const { panX, panY, zoom } = this.transform();
        const spawnX = x !== undefined ? x : (-panX + 380 + (deps.length * 40)) / zoom;
        const spawnY = y !== undefined ? y : (-panY + 182 + (deps.length * 30)) / zoom;
        const newDep = {
            id: customData?.id || `dep-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            type: 'dependency',
            x: Math.round(spawnX),
            y: Math.round(spawnY),
            name: customData?.name || `Delay ${count}`,
            days: customData?.days ?? 14, // Minimal number of days / delay
            event: customData?.event || 'Number of Subjects',
            eventSubjectCount: customData?.eventSubjectCount ?? 6,
            precedingCohortIds: customData?.precedingCohortIds || [],
            dependentCohortIds: customData?.dependentCohortIds || [],
            icon: icon,
            color: customData?.color || '#000000', // Default dependency color to black
            description: customData?.description || ''
        };
        this.nodes.update(nodes => [...nodes, newDep]);
        this.allBlocksSection.set('dependencies');
        this.selectNode(newDep.id);
        return newDep;
    }
    // --- Preceding & Dependent Cohorts Wiring ---
    addConnection(fromNodeId, fromPort, toNodeId, toPort, label) {
        const fromNode = this.nodes().find(n => n.id === fromNodeId);
        const toNode = this.nodes().find(n => n.id === toNodeId);
        if (!fromNode || !toNode)
            return false;
        // Rule 1: No direct Cohort-to-Cohort
        if (fromNode.type === 'cohort' && toNode.type === 'cohort')
            return false;
        // Rule 2: No direct Dependency-to-Dependency
        if (fromNode.type === 'dependency' && toNode.type === 'dependency')
            return false;
        // Rule 3: Cycle detection
        if (this.hasPath(toNodeId, fromNodeId))
            return false;
        const exists = this.connections().some(c => c.fromNodeId === fromNodeId && c.toNodeId === toNodeId);
        if (exists)
            return false;
        const newConn = {
            id: `conn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            fromNodeId,
            fromPort,
            toNodeId,
            toPort,
            label,
            color: '#0284c7'
        };
        this.connections.update(conns => [...conns, newConn]);
        return true;
    }
    isCohortPreceding(dependencyId, cohortId) {
        return this.connections().some(c => c.fromNodeId === cohortId && c.toNodeId === dependencyId);
    }
    togglePrecedingCohort(dependencyId, cohortId) {
        const existing = this.connections().find(c => c.fromNodeId === cohortId && c.toNodeId === dependencyId);
        if (existing) {
            this.deleteConnection(existing.id);
        }
        else {
            this.addConnection(cohortId, 'right', dependencyId, 'left');
        }
    }
    isCohortDependent(dependencyId, cohortId) {
        return this.connections().some(c => c.fromNodeId === dependencyId && c.toNodeId === cohortId);
    }
    toggleDependentCohort(dependencyId, cohortId) {
        const existing = this.connections().find(c => c.fromNodeId === dependencyId && c.toNodeId === cohortId);
        if (existing) {
            this.deleteConnection(existing.id);
        }
        else {
            this.addConnection(dependencyId, 'right', cohortId, 'left');
        }
    }
    updateNodePosition(id, x, y) {
        this.nodes.update(nodes => nodes.map(node => (node.id === id ? { ...node, x, y } : node)));
    }
    updateNodeData(id, updates) {
        this.nodes.update(nodes => nodes.map(node => {
            if (node.id === id) {
                return { ...node, ...updates };
            }
            return node;
        }));
    }
    deleteNode(id) {
        this.connections.update(conns => conns.filter(c => c.fromNodeId !== id && c.toNodeId !== id));
        this.nodes.update(nodes => nodes.filter(n => n.id !== id));
        if (this.selectedNodeId() === id) {
            this.selectedNodeId.set(null);
            this.rightPanelTab.set('overview');
        }
    }
    // --- Connecting Interaction (Left / Right only) ---
    startConnection(nodeId, port, canvasX, canvasY) {
        const coords = this.getPortCoordinates(nodeId, port);
        this.activeConnecting.set({
            fromNodeId: nodeId,
            fromPort: port,
            startX: coords.x,
            startY: coords.y,
            currentX: canvasX,
            currentY: canvasY
        });
        this.selectedConnectionId.set(null);
    }
    updateConnectingPosition(canvasX, canvasY) {
        const current = this.activeConnecting();
        if (!current)
            return;
        this.activeConnecting.set({
            ...current,
            currentX: canvasX,
            currentY: canvasY
        });
    }
    completeConnection(toNodeId, toPort) {
        const active = this.activeConnecting();
        if (!active)
            return false;
        // Check validation: No Cohort-to-Cohort, no cycles, no self-loops
        if (!this.isValidTarget(toNodeId)) {
            this.cancelConnection();
            return false;
        }
        // Check if an identical connection already exists
        const exists = this.connections().some(c => c.fromNodeId === active.fromNodeId &&
            c.fromPort === active.fromPort &&
            c.toNodeId === toNodeId &&
            c.toPort === toPort);
        if (exists) {
            this.cancelConnection();
            return false;
        }
        const newConnection = {
            id: `conn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            fromNodeId: active.fromNodeId,
            fromPort: active.fromPort,
            toNodeId: toNodeId,
            toPort: toPort,
            color: '#0284c7'
        };
        this.connections.update(conns => [...conns, newConnection]);
        this.activeConnecting.set(null);
        this.selectedConnectionId.set(newConnection.id);
        return true;
    }
    cancelConnection() {
        this.activeConnecting.set(null);
    }
    deleteConnection(id) {
        this.connections.update(conns => conns.filter(c => c.id !== id));
        if (this.selectedConnectionId() === id) {
            this.selectedConnectionId.set(null);
            this.rightPanelTab.set('overview');
        }
    }
    updateConnection(id, updates) {
        this.connections.update(conns => conns.map(c => (c.id === id ? { ...c, ...updates } : c)));
    }
    // --- Selection & Panel Tabs ---
    selectNode(id) {
        this.selectedNodeId.set(id);
        this.selectedConnectionId.set(null);
        if (id) {
            this.isRightPanelOpen.set(true);
            this.rightPanelTab.set('details');
        }
    }
    selectConnection(id) {
        this.selectedConnectionId.set(id);
        this.selectedNodeId.set(null);
        if (id) {
            this.isRightPanelOpen.set(true);
            this.rightPanelTab.set('details');
        }
    }
    openOverviewPanel() {
        this.isRightPanelOpen.set(true);
        this.rightPanelTab.set('overview');
        this.selectedNodeId.set(null);
        this.selectedConnectionId.set(null);
    }
    setAllBlocksSection(section) {
        this.allBlocksSection.set(section);
    }
    toggleRightPanel() {
        const nextState = !this.isRightPanelOpen();
        this.isRightPanelOpen.set(nextState);
        if (nextState) {
            this.rightPanelTab.set('overview');
        }
    }
    clearSelection() {
        this.selectedNodeId.set(null);
        this.selectedConnectionId.set(null);
    }
    // --- Canvas Navigation ---
    setTransform(zoom, panX, panY) {
        this.transform.set({
            zoom: Math.min(2.5, Math.max(0.25, zoom)),
            panX,
            panY
        });
    }
    zoomBy(delta) {
        const current = this.transform();
        const newZoom = Math.min(2.5, Math.max(0.3, current.zoom + delta));
        this.transform.set({
            ...current,
            zoom: newZoom
        });
    }
    resetView() {
        this.transform.set({ zoom: 1, panX: 0, panY: 0 });
    }
    // --- Data Access & Save Method ---
    getData() {
        return {
            version: '1.0.0',
            nodes: this.nodes(),
            connections: this.connections()
        };
    }
    save() {
        return this.getData();
    }
    loadFlow(flow) {
        this.nodes.set(flow.nodes || []);
        this.connections.set(flow.connections || []);
        this.clearSelection();
    }
    clearAll() {
        this.nodes.set([]);
        this.connections.set([]);
        this.clearSelection();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortDesignerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortDesignerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortDesignerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class CohortNodeComponent {
    service = inject(CohortDesignerService);
    node;
    isSelected = false;
    readonly = false;
    selectNode = new EventEmitter();
    portClick = new EventEmitter();
    portMouseUp = new EventEmitter();
    deleteNode = new EventEmitter();
    resizeStart = new EventEmitter();
    isHovered = false;
    get cardWidth() {
        return this.node.width || (this.node.isExpanded ? 280 : 180);
    }
    get cardHeight() {
        return this.node.height || (this.node.isExpanded ? 54 : 50);
    }
    activeConnecting = this.service.activeConnecting;
    isConnectingActive = computed(() => !!this.activeConnecting());
    isSourceOfConnection = computed(() => this.activeConnecting()?.fromNodeId === this.node.id);
    // Validate whether this node is an allowed connection target (no cohort-to-cohort, no circular dependency)
    isValidConnectionTarget = computed(() => {
        return this.service.isValidTarget(this.node.id);
    });
    ports = ['left', 'right'];
    onCardClick(event) {
        event.stopPropagation();
        this.selectNode.emit(this.node.id);
    }
    onResizeMouseDown(side, event) {
        event.stopPropagation();
        event.preventDefault();
        this.resizeStart.emit({ nodeId: this.node.id, side, event });
    }
    toggleExpand(event) {
        event.stopPropagation();
        this.service.toggleCohortExpand(this.node.id);
    }
    onMouseEnter() {
        this.isHovered = true;
    }
    onMouseLeave() {
        this.isHovered = false;
    }
    onPortMouseDown(port, event) {
        event.stopPropagation();
        this.portClick.emit({ nodeId: this.node.id, port, event });
    }
    onPortMouseUp(port, event) {
        event.stopPropagation();
        this.portMouseUp.emit({ nodeId: this.node.id, port, event });
    }
    onPortMouseEnter(port) {
        this.service.hoveredPort.set({ nodeId: this.node.id, port });
    }
    onPortMouseLeave() {
        this.service.hoveredPort.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortNodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: CohortNodeComponent, isStandalone: true, selector: "lib-cohort-node", inputs: { node: "node", isSelected: "isSelected", readonly: "readonly" }, outputs: { selectNode: "selectNode", portClick: "portClick", portMouseUp: "portMouseUp", deleteNode: "deleteNode", resizeStart: "resizeStart" }, ngImport: i0, template: "<div \n  class=\"cohort-card\"\n  [class.selected]=\"isSelected\"\n  [class.expanded]=\"node.isExpanded\"\n  [class.connecting-target]=\"isValidConnectionTarget()\"\n  [style.width.px]=\"cardWidth\"\n  [style.height.px]=\"cardHeight\"\n  (click)=\"onCardClick($event)\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <!-- Floating Tooltip on Hover showing full cohort name -->\n  <div class=\"cohort-hover-tooltip\" *ngIf=\"isHovered && !isConnectingActive()\">\n    <span class=\"tooltip-name\" [style.color]=\"node.color || '#000000'\">{{ node.name }}</span>\n    <span class=\"tooltip-sub\">Randomized N={{ node.randomizationTarget || node.subjects }}</span>\n  </div>\n\n  <!-- Left In-Connector Port -->\n  <div\n    class=\"port-handle port-left\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'left'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('left', $event)\"\n    (mouseup)=\"onPortMouseUp('left', $event)\"\n    (mouseenter)=\"onPortMouseEnter('left')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"In connector (Left)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Main Card Content: Cohort Name & Randomized Subjects -->\n  <div class=\"card-content\">\n    <span \n      class=\"cohort-name\" \n      [style.color]=\"node.color || '#000000'\"\n      [title]=\"node.name\"\n    >\n      {{ node.name }}\n    </span>\n\n    <div class=\"card-right-group\">\n      <span class=\"subjects-badge\" title=\"Randomized subjects count\">\n        N={{ node.randomizationTarget || node.subjects }}\n      </span>\n    </div>\n  </div>\n\n  <!-- Right Out-Connector Port -->\n  <div\n    class=\"port-handle port-right\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'right'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('right', $event)\"\n    (mouseup)=\"onPortMouseUp('right', $event)\"\n    (mouseenter)=\"onPortMouseEnter('right')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"Out connector (Right)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Interactive Resize Handles on Sides -->\n  <ng-container *ngIf=\"!readonly\">\n    <!-- Right side resize handle -->\n    <div \n      class=\"resize-handle resize-right\"\n      (mousedown)=\"onResizeMouseDown('right', $event)\"\n      title=\"Drag side to resize width\"\n    ></div>\n\n    <!-- Left side resize handle -->\n    <div \n      class=\"resize-handle resize-left\"\n      (mousedown)=\"onResizeMouseDown('left', $event)\"\n      title=\"Drag side to resize width\"\n    ></div>\n\n    <!-- Bottom side resize handle -->\n    <div \n      class=\"resize-handle resize-bottom\"\n      (mousedown)=\"onResizeMouseDown('bottom', $event)\"\n      title=\"Drag side to resize height\"\n    ></div>\n\n    <!-- Bottom-right corner resize grip -->\n    <div \n      class=\"resize-handle resize-corner\"\n      (mousedown)=\"onResizeMouseDown('corner', $event)\"\n      title=\"Drag corner to resize card\"\n    >\n      <svg viewBox=\"0 0 10 10\" width=\"8\" height=\"8\">\n        <line x1=\"8\" y1=\"2\" x2=\"2\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n        <line x1=\"8\" y1=\"5\" x2=\"5\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n        <line x1=\"8\" y1=\"8\" x2=\"8\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n      </svg>\n    </div>\n  </ng-container>\n</div>\n", styles: [":host{display:block;-webkit-user-select:none;user-select:none}.cohort-card{position:relative;min-width:140px;min-height:44px;background:#fff;border-radius:8px;border:1px solid #e2e8f0;box-shadow:0 2px 4px #0000000d;display:flex;align-items:center;padding:0 10px;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;color:#1e293b;cursor:pointer;transition:box-shadow .15s ease,border-color .15s ease}.cohort-card:hover{box-shadow:0 4px 8px #00000014;border-color:#cbd5e1}.cohort-card.selected{box-shadow:0 0 0 2px #0284c7,0 4px 8px #00000014;border-color:#0284c7}.cohort-card.connecting-target{border-color:#38bdf8;background-color:#f0f9ff}.cohort-hover-tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:#0f172a;color:#fff;padding:6px 10px;border-radius:6px;font-size:11px;white-space:nowrap;pointer-events:none;z-index:100;box-shadow:0 4px 12px #0003;display:flex;flex-direction:column;gap:2px;align-items:center;animation:tooltip-fade-in .15s ease}.cohort-hover-tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border:5px solid transparent;border-top-color:#0f172a}.cohort-hover-tooltip .tooltip-name{font-weight:700}.cohort-hover-tooltip .tooltip-sub{font-size:9px;color:#94a3b8}@keyframes tooltip-fade-in{0%{opacity:0;transform:translate(-50%,4px)}to{opacity:1;transform:translate(-50%)}}.card-content{display:flex;align-items:center;justify-content:space-between;width:100%;gap:6px;overflow:hidden}.cohort-name{font-size:13px;font-weight:700;color:#000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;transition:all .15s ease}.cohort-name.expanded-text{white-space:normal;line-height:1.2;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.card-right-group{display:flex;align-items:center;gap:4px;flex-shrink:0}.subjects-badge{font-size:10px;font-weight:700;background:#f1f5f9;color:#334155;padding:2px 6px;border-radius:10px;border:1px solid #e2e8f0;white-space:nowrap}.resize-handle{position:absolute;z-index:8;opacity:0;transition:opacity .15s ease}.resize-handle:after{content:\"\";position:absolute;background:#0284c7;border-radius:1px;opacity:.35;transition:opacity .15s ease,background .15s ease,box-shadow .15s ease}.resize-handle:hover:after{opacity:1;background:#0284c7;box-shadow:0 0 4px #0284c780}.resize-handle.resize-right{top:4px;right:-4px;width:8px;height:calc(100% - 8px);cursor:ew-resize}.resize-handle.resize-right:after{top:0;bottom:0;left:3px;width:2px;height:100%}.resize-handle.resize-left{top:4px;left:-4px;width:8px;height:calc(100% - 8px);cursor:ew-resize}.resize-handle.resize-left:after{top:0;bottom:0;right:3px;width:2px;height:100%}.resize-handle.resize-bottom{bottom:-4px;left:4px;height:8px;width:calc(100% - 8px);cursor:ns-resize}.resize-handle.resize-bottom:after{left:0;right:0;top:3px;height:2px;width:100%}.resize-handle.resize-corner{bottom:0;right:0;width:12px;height:12px;cursor:nwse-resize;display:flex;align-items:flex-end;justify-content:flex-end;padding:2px;box-sizing:border-box;opacity:0}.resize-handle.resize-corner:after{display:none}.resize-handle.resize-corner svg line{stroke:#94a3b8;stroke-width:1.2px;transition:stroke .15s ease}.resize-handle.resize-corner:hover{opacity:1!important}.resize-handle.resize-corner:hover svg line{stroke:#0284c7}.cohort-card:hover .resize-corner{opacity:.6}.cohort-card:hover .resize-handle{opacity:1}.cohort-card:hover .resize-handle:after{opacity:.35}.cohort-card:hover .resize-handle:hover:after{opacity:1}.port-handle{position:absolute;top:calc(50% - 9px);width:18px;height:18px;display:flex;align-items:center;justify-content:center;z-index:10;cursor:crosshair}.port-handle .port-dot{width:8px;height:8px;background:#fff;border:2px solid #64748b;border-radius:50%;transition:all .15s ease}.port-handle:hover .port-dot,.port-handle.active-source .port-dot{background:#0284c7;border-color:#0284c7;transform:scale(1.3);box-shadow:0 0 6px #0284c799}.port-handle.active-target-glow .port-dot{background:#38bdf8;border-color:#0284c7;transform:scale(1.2)}.port-handle.port-left{left:-9px}.port-handle.port-right{right:-9px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortNodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-cohort-node', standalone: true, imports: [CommonModule], template: "<div \n  class=\"cohort-card\"\n  [class.selected]=\"isSelected\"\n  [class.expanded]=\"node.isExpanded\"\n  [class.connecting-target]=\"isValidConnectionTarget()\"\n  [style.width.px]=\"cardWidth\"\n  [style.height.px]=\"cardHeight\"\n  (click)=\"onCardClick($event)\"\n  (mouseenter)=\"onMouseEnter()\"\n  (mouseleave)=\"onMouseLeave()\"\n>\n  <!-- Floating Tooltip on Hover showing full cohort name -->\n  <div class=\"cohort-hover-tooltip\" *ngIf=\"isHovered && !isConnectingActive()\">\n    <span class=\"tooltip-name\" [style.color]=\"node.color || '#000000'\">{{ node.name }}</span>\n    <span class=\"tooltip-sub\">Randomized N={{ node.randomizationTarget || node.subjects }}</span>\n  </div>\n\n  <!-- Left In-Connector Port -->\n  <div\n    class=\"port-handle port-left\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'left'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('left', $event)\"\n    (mouseup)=\"onPortMouseUp('left', $event)\"\n    (mouseenter)=\"onPortMouseEnter('left')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"In connector (Left)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Main Card Content: Cohort Name & Randomized Subjects -->\n  <div class=\"card-content\">\n    <span \n      class=\"cohort-name\" \n      [style.color]=\"node.color || '#000000'\"\n      [title]=\"node.name\"\n    >\n      {{ node.name }}\n    </span>\n\n    <div class=\"card-right-group\">\n      <span class=\"subjects-badge\" title=\"Randomized subjects count\">\n        N={{ node.randomizationTarget || node.subjects }}\n      </span>\n    </div>\n  </div>\n\n  <!-- Right Out-Connector Port -->\n  <div\n    class=\"port-handle port-right\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'right'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('right', $event)\"\n    (mouseup)=\"onPortMouseUp('right', $event)\"\n    (mouseenter)=\"onPortMouseEnter('right')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"Out connector (Right)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Interactive Resize Handles on Sides -->\n  <ng-container *ngIf=\"!readonly\">\n    <!-- Right side resize handle -->\n    <div \n      class=\"resize-handle resize-right\"\n      (mousedown)=\"onResizeMouseDown('right', $event)\"\n      title=\"Drag side to resize width\"\n    ></div>\n\n    <!-- Left side resize handle -->\n    <div \n      class=\"resize-handle resize-left\"\n      (mousedown)=\"onResizeMouseDown('left', $event)\"\n      title=\"Drag side to resize width\"\n    ></div>\n\n    <!-- Bottom side resize handle -->\n    <div \n      class=\"resize-handle resize-bottom\"\n      (mousedown)=\"onResizeMouseDown('bottom', $event)\"\n      title=\"Drag side to resize height\"\n    ></div>\n\n    <!-- Bottom-right corner resize grip -->\n    <div \n      class=\"resize-handle resize-corner\"\n      (mousedown)=\"onResizeMouseDown('corner', $event)\"\n      title=\"Drag corner to resize card\"\n    >\n      <svg viewBox=\"0 0 10 10\" width=\"8\" height=\"8\">\n        <line x1=\"8\" y1=\"2\" x2=\"2\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n        <line x1=\"8\" y1=\"5\" x2=\"5\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n        <line x1=\"8\" y1=\"8\" x2=\"8\" y2=\"8\" stroke=\"#94a3b8\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n      </svg>\n    </div>\n  </ng-container>\n</div>\n", styles: [":host{display:block;-webkit-user-select:none;user-select:none}.cohort-card{position:relative;min-width:140px;min-height:44px;background:#fff;border-radius:8px;border:1px solid #e2e8f0;box-shadow:0 2px 4px #0000000d;display:flex;align-items:center;padding:0 10px;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;color:#1e293b;cursor:pointer;transition:box-shadow .15s ease,border-color .15s ease}.cohort-card:hover{box-shadow:0 4px 8px #00000014;border-color:#cbd5e1}.cohort-card.selected{box-shadow:0 0 0 2px #0284c7,0 4px 8px #00000014;border-color:#0284c7}.cohort-card.connecting-target{border-color:#38bdf8;background-color:#f0f9ff}.cohort-hover-tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:#0f172a;color:#fff;padding:6px 10px;border-radius:6px;font-size:11px;white-space:nowrap;pointer-events:none;z-index:100;box-shadow:0 4px 12px #0003;display:flex;flex-direction:column;gap:2px;align-items:center;animation:tooltip-fade-in .15s ease}.cohort-hover-tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border:5px solid transparent;border-top-color:#0f172a}.cohort-hover-tooltip .tooltip-name{font-weight:700}.cohort-hover-tooltip .tooltip-sub{font-size:9px;color:#94a3b8}@keyframes tooltip-fade-in{0%{opacity:0;transform:translate(-50%,4px)}to{opacity:1;transform:translate(-50%)}}.card-content{display:flex;align-items:center;justify-content:space-between;width:100%;gap:6px;overflow:hidden}.cohort-name{font-size:13px;font-weight:700;color:#000;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;transition:all .15s ease}.cohort-name.expanded-text{white-space:normal;line-height:1.2;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.card-right-group{display:flex;align-items:center;gap:4px;flex-shrink:0}.subjects-badge{font-size:10px;font-weight:700;background:#f1f5f9;color:#334155;padding:2px 6px;border-radius:10px;border:1px solid #e2e8f0;white-space:nowrap}.resize-handle{position:absolute;z-index:8;opacity:0;transition:opacity .15s ease}.resize-handle:after{content:\"\";position:absolute;background:#0284c7;border-radius:1px;opacity:.35;transition:opacity .15s ease,background .15s ease,box-shadow .15s ease}.resize-handle:hover:after{opacity:1;background:#0284c7;box-shadow:0 0 4px #0284c780}.resize-handle.resize-right{top:4px;right:-4px;width:8px;height:calc(100% - 8px);cursor:ew-resize}.resize-handle.resize-right:after{top:0;bottom:0;left:3px;width:2px;height:100%}.resize-handle.resize-left{top:4px;left:-4px;width:8px;height:calc(100% - 8px);cursor:ew-resize}.resize-handle.resize-left:after{top:0;bottom:0;right:3px;width:2px;height:100%}.resize-handle.resize-bottom{bottom:-4px;left:4px;height:8px;width:calc(100% - 8px);cursor:ns-resize}.resize-handle.resize-bottom:after{left:0;right:0;top:3px;height:2px;width:100%}.resize-handle.resize-corner{bottom:0;right:0;width:12px;height:12px;cursor:nwse-resize;display:flex;align-items:flex-end;justify-content:flex-end;padding:2px;box-sizing:border-box;opacity:0}.resize-handle.resize-corner:after{display:none}.resize-handle.resize-corner svg line{stroke:#94a3b8;stroke-width:1.2px;transition:stroke .15s ease}.resize-handle.resize-corner:hover{opacity:1!important}.resize-handle.resize-corner:hover svg line{stroke:#0284c7}.cohort-card:hover .resize-corner{opacity:.6}.cohort-card:hover .resize-handle{opacity:1}.cohort-card:hover .resize-handle:after{opacity:.35}.cohort-card:hover .resize-handle:hover:after{opacity:1}.port-handle{position:absolute;top:calc(50% - 9px);width:18px;height:18px;display:flex;align-items:center;justify-content:center;z-index:10;cursor:crosshair}.port-handle .port-dot{width:8px;height:8px;background:#fff;border:2px solid #64748b;border-radius:50%;transition:all .15s ease}.port-handle:hover .port-dot,.port-handle.active-source .port-dot{background:#0284c7;border-color:#0284c7;transform:scale(1.3);box-shadow:0 0 6px #0284c799}.port-handle.active-target-glow .port-dot{background:#38bdf8;border-color:#0284c7;transform:scale(1.2)}.port-handle.port-left{left:-9px}.port-handle.port-right{right:-9px}\n"] }]
        }], propDecorators: { node: [{
                type: Input,
                args: [{ required: true }]
            }], isSelected: [{
                type: Input
            }], readonly: [{
                type: Input
            }], selectNode: [{
                type: Output
            }], portClick: [{
                type: Output
            }], portMouseUp: [{
                type: Output
            }], deleteNode: [{
                type: Output
            }], resizeStart: [{
                type: Output
            }] } });

class DependencyNodeComponent {
    service = inject(CohortDesignerService);
    sanitizer = inject(DomSanitizer);
    node;
    isSelected = false;
    readonly = false;
    customIcons = [];
    selectNode = new EventEmitter();
    portClick = new EventEmitter();
    portMouseUp = new EventEmitter();
    deleteNode = new EventEmitter();
    activeConnecting = this.service.activeConnecting;
    isConnectingActive = computed(() => !!this.activeConnecting());
    isSourceOfConnection = computed(() => this.activeConnecting()?.fromNodeId === this.node.id);
    // Validate whether this dependency is an allowed connection target (no dep-to-dep, no circular dependency)
    isValidConnectionTarget = computed(() => {
        return this.service.isValidTarget(this.node.id);
    });
    ports = ['left', 'right'];
    iconSvg = computed(() => {
        if (this.node.customSvg) {
            return this.sanitizer.bypassSecurityTrustHtml(this.node.customSvg);
        }
        const svg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14" stroke-linecap="round"/></svg>`;
        return this.sanitizer.bypassSecurityTrustHtml(svg);
    });
    onNodeClick(event) {
        event.stopPropagation();
        this.selectNode.emit(this.node.id);
    }
    onPortMouseDown(port, event) {
        event.stopPropagation();
        this.portClick.emit({ nodeId: this.node.id, port, event });
    }
    onPortMouseUp(port, event) {
        event.stopPropagation();
        this.portMouseUp.emit({ nodeId: this.node.id, port, event });
    }
    onPortMouseEnter(port) {
        this.service.hoveredPort.set({ nodeId: this.node.id, port });
    }
    onPortMouseLeave() {
        this.service.hoveredPort.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: DependencyNodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: DependencyNodeComponent, isStandalone: true, selector: "lib-dependency-node", inputs: { node: "node", isSelected: "isSelected", readonly: "readonly", customIcons: "customIcons" }, outputs: { selectNode: "selectNode", portClick: "portClick", portMouseUp: "portMouseUp", deleteNode: "deleteNode" }, ngImport: i0, template: "<div \n  class=\"dependency-wrapper\"\n  [class.selected]=\"isSelected\"\n  [class.connecting-target]=\"isValidConnectionTarget()\"\n  (click)=\"onNodeClick($event)\"\n>\n  <!-- Left In-Connector Port -->\n  <div\n    class=\"port-handle port-left\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'left'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('left', $event)\"\n    (mouseup)=\"onPortMouseUp('left', $event)\"\n    (mouseenter)=\"onPortMouseEnter('left')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"In connector (Left)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Circular Icon Node -->\n  <div \n    class=\"icon-circle\"\n    [style.border-color]=\"node.color || '#000000'\"\n    [style.color]=\"node.color || '#000000'\"\n  >\n    <div class=\"icon-inner\" [innerHTML]=\"iconSvg()\"></div>\n  </div>\n\n  <!-- Right Out-Connector Port -->\n  <div\n    class=\"port-handle port-right\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'right'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('right', $event)\"\n    (mouseup)=\"onPortMouseUp('right', $event)\"\n    (mouseenter)=\"onPortMouseEnter('right')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"Out connector (Right)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Minimal Days / Delay Badge -->\n  <div class=\"days-badge\" [title]=\"node.name + ' - ' + node.days + ' days minimal delay'\">\n    {{ node.days }}d\n  </div>\n</div>\n", styles: [":host{display:block;-webkit-user-select:none;user-select:none}.dependency-wrapper{position:relative;width:46px;height:46px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}.dependency-wrapper.selected .icon-circle{box-shadow:0 0 0 2px #0284c7,0 4px 8px #0000001f}.dependency-wrapper.connecting-target .icon-circle{box-shadow:0 0 0 2px #38bdf8}.icon-circle{width:42px;height:42px;border-radius:50%;border:2px solid #000000;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 4px #0000000f;transition:all .15s ease}.icon-circle:hover{transform:translateY(-1px);box-shadow:0 4px 6px #00000014}.icon-circle .icon-inner{display:flex;align-items:center;justify-content:center}.port-handle{position:absolute;top:calc(50% - 9px);width:18px;height:18px;display:flex;align-items:center;justify-content:center;z-index:10;cursor:crosshair}.port-handle .port-dot{width:8px;height:8px;background:#fff;border:2px solid #0d9488;border-radius:50%;transition:all .15s ease}.port-handle:hover .port-dot,.port-handle.active-source .port-dot{background:#0284c7;border-color:#0284c7;transform:scale(1.3);box-shadow:0 0 6px #0284c799}.port-handle.active-target-glow .port-dot{background:#38bdf8;border-color:#0284c7;transform:scale(1.2)}.port-handle.port-left{left:-9px}.port-handle.port-right{right:-9px}.days-badge{position:absolute;top:42px;left:50%;transform:translate(-50%);font-size:10px;font-weight:700;color:#1e293b;background:#f8fafc;border:1px solid #e2e8f0;padding:1px 6px;border-radius:10px;white-space:nowrap;pointer-events:none;box-shadow:0 1px 2px #0000000a}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: DependencyNodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-dependency-node', standalone: true, imports: [CommonModule], template: "<div \n  class=\"dependency-wrapper\"\n  [class.selected]=\"isSelected\"\n  [class.connecting-target]=\"isValidConnectionTarget()\"\n  (click)=\"onNodeClick($event)\"\n>\n  <!-- Left In-Connector Port -->\n  <div\n    class=\"port-handle port-left\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'left'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('left', $event)\"\n    (mouseup)=\"onPortMouseUp('left', $event)\"\n    (mouseenter)=\"onPortMouseEnter('left')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"In connector (Left)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Circular Icon Node -->\n  <div \n    class=\"icon-circle\"\n    [style.border-color]=\"node.color || '#000000'\"\n    [style.color]=\"node.color || '#000000'\"\n  >\n    <div class=\"icon-inner\" [innerHTML]=\"iconSvg()\"></div>\n  </div>\n\n  <!-- Right Out-Connector Port -->\n  <div\n    class=\"port-handle port-right\"\n    [class.active-source]=\"isSourceOfConnection() && activeConnecting()?.fromPort === 'right'\"\n    [class.active-target-glow]=\"isValidConnectionTarget()\"\n    (mousedown)=\"onPortMouseDown('right', $event)\"\n    (mouseup)=\"onPortMouseUp('right', $event)\"\n    (mouseenter)=\"onPortMouseEnter('right')\"\n    (mouseleave)=\"onPortMouseLeave()\"\n    title=\"Out connector (Right)\"\n  >\n    <div class=\"port-dot\"></div>\n  </div>\n\n  <!-- Minimal Days / Delay Badge -->\n  <div class=\"days-badge\" [title]=\"node.name + ' - ' + node.days + ' days minimal delay'\">\n    {{ node.days }}d\n  </div>\n</div>\n", styles: [":host{display:block;-webkit-user-select:none;user-select:none}.dependency-wrapper{position:relative;width:46px;height:46px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}.dependency-wrapper.selected .icon-circle{box-shadow:0 0 0 2px #0284c7,0 4px 8px #0000001f}.dependency-wrapper.connecting-target .icon-circle{box-shadow:0 0 0 2px #38bdf8}.icon-circle{width:42px;height:42px;border-radius:50%;border:2px solid #000000;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 4px #0000000f;transition:all .15s ease}.icon-circle:hover{transform:translateY(-1px);box-shadow:0 4px 6px #00000014}.icon-circle .icon-inner{display:flex;align-items:center;justify-content:center}.port-handle{position:absolute;top:calc(50% - 9px);width:18px;height:18px;display:flex;align-items:center;justify-content:center;z-index:10;cursor:crosshair}.port-handle .port-dot{width:8px;height:8px;background:#fff;border:2px solid #0d9488;border-radius:50%;transition:all .15s ease}.port-handle:hover .port-dot,.port-handle.active-source .port-dot{background:#0284c7;border-color:#0284c7;transform:scale(1.3);box-shadow:0 0 6px #0284c799}.port-handle.active-target-glow .port-dot{background:#38bdf8;border-color:#0284c7;transform:scale(1.2)}.port-handle.port-left{left:-9px}.port-handle.port-right{right:-9px}.days-badge{position:absolute;top:42px;left:50%;transform:translate(-50%);font-size:10px;font-weight:700;color:#1e293b;background:#f8fafc;border:1px solid #e2e8f0;padding:1px 6px;border-radius:10px;white-space:nowrap;pointer-events:none;box-shadow:0 1px 2px #0000000a}\n"] }]
        }], propDecorators: { node: [{
                type: Input,
                args: [{ required: true }]
            }], isSelected: [{
                type: Input
            }], readonly: [{
                type: Input
            }], customIcons: [{
                type: Input
            }], selectNode: [{
                type: Output
            }], portClick: [{
                type: Output
            }], portMouseUp: [{
                type: Output
            }], deleteNode: [{
                type: Output
            }] } });

const CLINICAL_ICONS = [
    {
        id: 'clock',
        name: 'Delay / Time',
        viewBox: '0 0 24 24',
        svgPath: `
      <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="2"/>
      <polyline points="12 6 12 12 16 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    `
    },
    {
        id: 'calendar',
        name: 'Minimal Days / Interval',
        viewBox: '0 0 24 24',
        svgPath: `
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" fill="none" stroke="currentColor" stroke-width="2"/>
      <line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" stroke-width="2"/>
      <line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" stroke-width="2"/>
      <line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" stroke-width="2"/>
    `
    },
    {
        id: 'shield',
        name: 'Safety / DLT Gate',
        viewBox: '0 0 24 24',
        svgPath: `
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M9 12l2 2 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    `
    },
    {
        id: 'scale',
        name: 'Randomization',
        viewBox: '0 0 24 24',
        svgPath: `
      <path d="M12 3v18M3 7l4 8M17 15l4-8M3 7h8M13 7h8M7 15a4 4 0 0 0-8 0h8zm14 0a4 4 0 0 0-8 0h8z" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    `
    },
    {
        id: 'beaker',
        name: 'Biomarker / Assay',
        viewBox: '0 0 24 24',
        svgPath: `
      <path d="M4.5 3h15M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3M6 14h12M10 3v5M14 3v3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    `
    },
    {
        id: 'check-circle',
        name: 'Clearance Gate',
        viewBox: '0 0 24 24',
        svgPath: `
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <polyline points="22 4 12 14.01 9 11.01" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    `
    },
    {
        id: 'diamond',
        name: 'Decision Gate',
        viewBox: '0 0 24 24',
        svgPath: `
      <polygon points="12 2 22 12 12 22 2 12 12 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    `
    },
    {
        id: 'git-branch',
        name: 'Split / Crossover',
        viewBox: '0 0 24 24',
        svgPath: `
      <line x1="6" y1="3" x2="6" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      <circle cx="18" cy="6" r="3" fill="none" stroke="currentColor" stroke-width="2"/>
      <circle cx="6" cy="18" r="3" fill="none" stroke="currentColor" stroke-width="2"/>
      <path d="M18 9a9 9 0 0 1-9 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    `
    }
];

class InspectorPanelComponent {
    service = inject(CohortDesignerService);
    sanitizer = inject(DomSanitizer);
    node = null;
    connection = null;
    customIcons = [];
    readonly = false;
    close = new EventEmitter();
    activeTab = this.service.rightPanelTab;
    cohorts = this.service.cohortNodes;
    dependencies = this.service.dependencyNodes;
    allBlocksSection = this.service.allBlocksSection;
    totalRandomizedSubjects = computed(() => {
        return this.cohorts().reduce((sum, c) => sum + (c.subjects || 0), 0);
    });
    // Color palette with Default Black first
    themeColors = [
        { name: 'Default Black', hex: '#000000' },
        { name: 'Sky Blue', hex: '#0284c7' },
        { name: 'Indigo', hex: '#4f46e5' },
        { name: 'Emerald', hex: '#059669' },
        { name: 'Amber', hex: '#d97706' },
        { name: 'Rose', hex: '#e11d48' },
        { name: 'Violet', hex: '#7c3aed' },
        { name: 'Slate', hex: '#475569' }
    ];
    get allIcons() {
        return [...this.customIcons, ...CLINICAL_ICONS];
    }
    get isCohort() {
        return this.node?.type === 'cohort';
    }
    get isDependency() {
        return this.node?.type === 'dependency';
    }
    get cohortNode() {
        return this.node;
    }
    get dependencyNode() {
        return this.node;
    }
    getSafeIcon(icon) {
        const svg = `<svg viewBox="${icon.viewBox || '0 0 24 24'}" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">${icon.svgPath}</svg>`;
        return this.sanitizer.bypassSecurityTrustHtml(svg);
    }
    getSafeIconById(_iconId) {
        const svg = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14" stroke-linecap="round"/></svg>`;
        return this.sanitizer.bypassSecurityTrustHtml(svg);
    }
    setTab(tab) {
        this.service.rightPanelTab.set(tab);
    }
    setAllBlocksSection(section) {
        this.service.setAllBlocksSection(section);
    }
    // --- Simultaneous Batch Editing Handlers ---
    onCohortChange(cohort) {
        if (cohort.randomizationTarget !== undefined) {
            cohort.subjects = cohort.randomizationTarget;
        }
        this.service.updateNodeData(cohort.id, cohort);
    }
    isCohortPreceding(dependencyId, cohortId) {
        return this.service.isCohortPreceding(dependencyId, cohortId);
    }
    togglePrecedingCohort(dependencyId, cohortId) {
        this.service.togglePrecedingCohort(dependencyId, cohortId);
    }
    isCohortDependent(dependencyId, cohortId) {
        return this.service.isCohortDependent(dependencyId, cohortId);
    }
    toggleDependentCohort(dependencyId, cohortId) {
        this.service.toggleDependentCohort(dependencyId, cohortId);
    }
    setCohortColor(cohort, colorHex) {
        cohort.color = colorHex;
        this.service.updateNodeData(cohort.id, cohort);
    }
    setDependencyColor(dep, colorHex) {
        dep.color = colorHex;
        this.service.updateNodeData(dep.id, dep);
    }
    toggleCohortExpand(cohort) {
        cohort.isExpanded = !cohort.isExpanded;
        this.service.updateNodeData(cohort.id, cohort);
    }
    resetCohortDimensions(id) {
        this.service.resetCohortDimensions(id);
    }
    onDimensionChange() {
        if (this.node && this.node.type === 'cohort') {
            const c = this.node;
            const w = Math.max(140, Math.min(700, c.width || 180));
            const h = Math.max(44, Math.min(260, c.height || 50));
            this.service.updateNodeDimensions(c.id, w, h);
        }
    }
    deleteCohort(id) {
        this.service.deleteNode(id);
    }
    onDependencyChange(dep) {
        this.service.updateNodeData(dep.id, dep);
    }
    setDependencyIcon(dep, iconId) {
        dep.icon = iconId;
        this.service.updateNodeData(dep.id, dep);
    }
    deleteDependency(id) {
        this.service.deleteNode(id);
    }
    addNewCohort() {
        this.service.addCohort();
    }
    addNewDependency() {
        this.service.addDependency();
    }
    // --- Selected Single Node Handlers ---
    onFieldChange() {
        if (this.node) {
            this.service.updateNodeData(this.node.id, this.node);
        }
    }
    onConnectionFieldChange() {
        if (this.connection) {
            this.service.updateConnection(this.connection.id, this.connection);
        }
    }
    selectIcon(iconId) {
        if (this.dependencyNode) {
            this.dependencyNode.icon = iconId;
            this.onFieldChange();
        }
    }
    deleteCurrentNode() {
        if (this.node) {
            this.service.deleteNode(this.node.id);
        }
    }
    deleteCurrentConnection() {
        if (this.connection) {
            this.service.deleteConnection(this.connection.id);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: InspectorPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: InspectorPanelComponent, isStandalone: true, selector: "lib-inspector-panel", inputs: { node: "node", connection: "connection", customIcons: "customIcons", readonly: "readonly" }, outputs: { close: "close" }, ngImport: i0, template: "<div class=\"inspector-drawer\">\n  <!-- Clean Drawer Header -->\n  <div class=\"drawer-header\">\n    <div class=\"header-left\">\n      <!-- In Overview mode: Show clean Title -->\n      <span class=\"panel-header-title\" *ngIf=\"activeTab() === 'overview'\">\n        All Blocks ({{ cohorts().length + dependencies().length }})\n      </span>\n\n      <!-- In Single Section Details mode: Clean button to show All Blocks -->\n      <button \n        type=\"button\" \n        class=\"btn-show-all-blocks\" \n        *ngIf=\"activeTab() === 'details'\"\n        (click)=\"setTab('overview')\"\n        title=\"Show all cohorts and dependencies together\"\n      >\n        <svg viewBox=\"0 0 24 24\" width=\"13\" height=\"13\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n          <line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line>\n          <polyline points=\"12 19 5 12 12 5\"></polyline>\n        </svg>\n        <span>All Blocks ({{ cohorts().length + dependencies().length }})</span>\n      </button>\n\n      <span class=\"panel-details-subtitle\" *ngIf=\"activeTab() === 'details'\">\n        &bull; {{ isCohort ? (cohortNode.name || 'Cohort') : isDependency ? (dependencyNode.name || 'Delay') : 'Connection' }}\n      </span>\n    </div>\n\n    <button type=\"button\" class=\"close-btn\" (click)=\"close.emit()\" title=\"Close panel\">\n      &times;\n    </button>\n  </div>\n\n  <!-- Drawer Body -->\n  <div class=\"drawer-body\">\n\n    <!-- ==================== TAB 1: ALL BLOCKS SIMULTANEOUS BATCH EDITING ==================== -->\n    <div *ngIf=\"activeTab() === 'overview'\" class=\"overview-container\">\n      \n      <!-- Section Switcher: Switch between Cohorts and Dependencies -->\n      <div class=\"all-blocks-switcher\">\n        <button \n          type=\"button\" \n          class=\"switcher-btn cohort-btn\"\n          [class.active]=\"allBlocksSection() === 'cohorts'\"\n          (click)=\"setAllBlocksSection('cohorts')\"\n        >\n          <span class=\"switcher-dot cohort\"></span>\n          <span>Cohorts ({{ cohorts().length }})</span>\n          <span class=\"switcher-badge\" *ngIf=\"cohorts().length > 0\">N={{ totalRandomizedSubjects() }}</span>\n        </button>\n\n        <button \n          type=\"button\" \n          class=\"switcher-btn dep-btn\"\n          [class.active]=\"allBlocksSection() === 'dependencies'\"\n          (click)=\"setAllBlocksSection('dependencies')\"\n        >\n          <span class=\"switcher-dot dep\"></span>\n          <span>Dependencies ({{ dependencies().length }})</span>\n        </button>\n      </div>\n\n      <!-- SECTION 1: COHORTS (VERTICAL MODE IN SEQUENCE LEFT TO RIGHT) -->\n      <div class=\"overview-section\" *ngIf=\"allBlocksSection() === 'cohorts'\">\n        <div class=\"section-title-row\">\n          <div class=\"section-title-group\">\n            <span class=\"section-title\">Cohorts</span>\n            <span class=\"section-sub\" *ngIf=\"cohorts().length > 0\">\n              {{ cohorts().length }} Cohort{{ cohorts().length === 1 ? '' : 's' }} &bull; Total Randomized N={{ totalRandomizedSubjects() }}\n            </span>\n          </div>\n        </div>\n\n        <div class=\"overview-cards-list vertical-cards-list\" *ngIf=\"cohorts().length > 0\">\n          <div \n            class=\"batch-vertical-card cohort-v-card\" \n            *ngFor=\"let c of cohorts(); let i = index\"\n            [style.borderLeftColor]=\"c.color || '#000000'\"\n          >\n            <!-- Card Header -->\n            <div class=\"v-card-header\">\n              <div class=\"header-left\">\n                <span class=\"index-badge\">#{{ i + 1 }}</span>\n                <span class=\"card-headline\" [style.color]=\"c.color || '#000000'\">\n                  {{ c.name }}\n                </span>\n                <span class=\"subjects-pill\">N={{ c.randomizationTarget || c.subjects }}</span>\n              </div>\n\n              <div class=\"header-right\" *ngIf=\"!readonly\">\n                <button \n                  type=\"button\" \n                  class=\"btn-card-delete\" \n                  (click)=\"deleteCohort(c.id)\"\n                  title=\"Delete this cohort\"\n                >\n                  &times;\n                </button>\n              </div>\n            </div>\n\n            <!-- Card Body in Vertical Mode -->\n            <div class=\"v-card-body\">\n              <!-- Cohort Name -->\n              <div class=\"v-input-group\">\n                <label>Cohort Name</label>\n                <input \n                  type=\"text\" \n                  [(ngModel)]=\"c.name\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  [style.color]=\"c.color || '#000000'\"\n                  placeholder=\"e.g. Cohort A\" \n                  [disabled]=\"readonly\"\n                />\n              </div>\n\n              <!-- Cohort Level (Radio: Worldwide | Country) -->\n              <div class=\"v-input-group\">\n                <label>Cohort Level</label>\n                <div class=\"radio-row\">\n                  <label class=\"radio-chip\" [class.active]=\"(c.cohortLevel || 'Worldwide') === 'Worldwide'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'cohort-level-' + c.id\" \n                      value=\"Worldwide\" \n                      [checked]=\"(c.cohortLevel || 'Worldwide') === 'Worldwide'\"\n                      (change)=\"c.cohortLevel = 'Worldwide'; onCohortChange(c)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Worldwide</span>\n                  </label>\n                  <label class=\"radio-chip\" [class.active]=\"c.cohortLevel === 'Country'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'cohort-level-' + c.id\" \n                      value=\"Country\" \n                      [checked]=\"c.cohortLevel === 'Country'\"\n                      (change)=\"c.cohortLevel = 'Country'; onCohortChange(c)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Country</span>\n                  </label>\n                </div>\n              </div>\n\n              <!-- Randomization Target & Screening Period -->\n              <div class=\"v-input-grid two-col\">\n                <div class=\"v-input-group\">\n                  <label>Randomization Target</label>\n                  <div class=\"n-input-wrapper\">\n                    <span class=\"n-prefix\">N=</span>\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"c.randomizationTarget\" \n                      (ngModelChange)=\"c.subjects = c.randomizationTarget || c.subjects; onCohortChange(c)\"\n                      min=\"1\" \n                      max=\"10000\"\n                      placeholder=\"20\"\n                      [disabled]=\"readonly\"\n                    />\n                  </div>\n                </div>\n\n                <div class=\"v-input-group\">\n                  <label>Screening Period</label>\n                  <div class=\"delay-input-wrapper\">\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"c.screeningPeriod\" \n                      (ngModelChange)=\"onCohortChange(c)\"\n                      min=\"0\" \n                      max=\"365\"\n                      placeholder=\"14\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"days-suffix\">days</span>\n                  </div>\n                </div>\n              </div>\n\n              <!-- Target Last Subject Randomized -->\n              <div class=\"v-input-group\">\n                <label>Target Last Subject Randomized</label>\n                <input \n                  type=\"date\" \n                  [(ngModel)]=\"c.targetLastSubjectRandomized\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  [disabled]=\"readonly\"\n                />\n              </div>\n\n              <!-- Color Palette -->\n              <div class=\"v-input-group\" *ngIf=\"!readonly\">\n                <label>Name Color (Default Black)</label>\n                <div class=\"color-palette mini-vertical\">\n                  <button\n                    type=\"button\"\n                    *ngFor=\"let col of themeColors\"\n                    class=\"color-dot\"\n                    [style.background]=\"col.hex\"\n                    [class.active]=\"(c.color || '#000000') === col.hex\"\n                    (click)=\"setCohortColor(c, col.hex)\"\n                    [title]=\"col.name\"\n                  ></button>\n                </div>\n              </div>\n\n              <!-- Description Log / Notes -->\n              <div class=\"v-input-group\">\n                <label>Description Log / Inclusion Criteria</label>\n                <textarea \n                  rows=\"2\"\n                  [(ngModel)]=\"c.description\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  placeholder=\"Eligibility criteria or notes for this cohort...\"\n                  [disabled]=\"readonly\"\n                ></textarea>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"empty-hint\" *ngIf=\"cohorts().length === 0\">\n          No cohorts on canvas yet. Click <strong>+ Select Cohort</strong> in the top header to add cohorts.\n        </div>\n      </div>\n\n      <!-- SECTION 2: DEPENDENCIES (VERTICAL MODE IN SEQUENCE LEFT TO RIGHT) -->\n      <div class=\"overview-section\" *ngIf=\"allBlocksSection() === 'dependencies'\">\n        <div class=\"section-title-row\">\n          <div class=\"section-title-group\">\n            <span class=\"section-title\">Dependencies & Delays</span>\n            <span class=\"section-sub\" *ngIf=\"dependencies().length > 0\">\n              {{ dependencies().length }} Delay Block{{ dependencies().length === 1 ? '' : 's' }}\n            </span>\n          </div>\n          <button \n            type=\"button\" \n            class=\"btn-section-add dep\" \n            *ngIf=\"!readonly\"\n            (click)=\"addNewDependency()\" \n            title=\"Add new dependency / delay\"\n          >\n            + Add Delay\n          </button>\n        </div>\n\n        <div class=\"overview-cards-list vertical-cards-list\" *ngIf=\"dependencies().length > 0\">\n          <div \n            class=\"batch-vertical-card dep-v-card\" \n            *ngFor=\"let d of dependencies(); let j = index\"\n            [style.borderLeftColor]=\"d.color || '#000000'\"\n          >\n            <!-- Card Header -->\n            <div class=\"v-card-header\">\n              <div class=\"header-left\">\n                <span class=\"index-badge dep\" [style.color]=\"d.color || '#000000'\">#{{ j + 1 }}</span>\n                <span class=\"dep-icon-preview\" [style.color]=\"d.color || '#000000'\" [innerHTML]=\"getSafeIconById(d.icon)\"></span>\n                <span class=\"card-headline dep\" [style.color]=\"d.color || '#000000'\">{{ d.name }}</span>\n                <span class=\"delay-pill\">{{ d.days }}d delay</span>\n              </div>\n\n              <div class=\"header-right\" *ngIf=\"!readonly\">\n                <button \n                  type=\"button\" \n                  class=\"btn-card-delete\" \n                  (click)=\"deleteDependency(d.id)\"\n                  title=\"Delete this dependency\"\n                >\n                  &times;\n                </button>\n              </div>\n            </div>\n\n            <!-- Card Body in Vertical Mode -->\n            <div class=\"v-card-body\">\n              <div class=\"v-input-grid two-col\">\n                <div class=\"v-input-group\">\n                  <label>Dependency Label</label>\n                  <input \n                    type=\"text\" \n                    [(ngModel)]=\"d.name\" \n                    (ngModelChange)=\"onDependencyChange(d)\"\n                    placeholder=\"e.g. Safety Delay\" \n                    [disabled]=\"readonly\"\n                  />\n                </div>\n\n                <div class=\"v-input-group\">\n                  <label>Minimal Delay</label>\n                  <div class=\"delay-input-wrapper\">\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"d.days\" \n                      (ngModelChange)=\"onDependencyChange(d)\"\n                      min=\"0\" \n                      max=\"365\"\n                      placeholder=\"14\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"days-suffix\">days</span>\n                  </div>\n                </div>\n              </div>\n\n              <!-- Preceding Cohort(s) -->\n              <div class=\"v-input-group\">\n                <label>Preceding Cohort(s)</label>\n                <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n                  <label \n                    *ngFor=\"let c of cohorts()\" \n                    class=\"cohort-chip-checkbox\" \n                    [class.checked]=\"isCohortPreceding(d.id, c.id)\"\n                    [title]=\"'Link ' + c.name + ' as preceding cohort'\"\n                  >\n                    <input \n                      type=\"checkbox\" \n                      [checked]=\"isCohortPreceding(d.id, c.id)\"\n                      (change)=\"togglePrecedingCohort(d.id, c.id)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n                    <span class=\"chip-name\">{{ c.name }}</span>\n                  </label>\n                </div>\n                <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas</span>\n              </div>\n\n              <!-- Event Gate (Radio: Number of Subjects | Enrollment Complete) -->\n              <div class=\"v-input-group\">\n                <label>Event Gate</label>\n                <div class=\"radio-row\">\n                  <label class=\"radio-chip\" [class.active]=\"d.event !== 'Enrollment Complete'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'dep-event-' + d.id\" \n                      value=\"Number of Subjects\" \n                      [checked]=\"d.event !== 'Enrollment Complete'\"\n                      (change)=\"d.event = 'Number of Subjects'; onDependencyChange(d)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Number of Subjects</span>\n                  </label>\n                  <label class=\"radio-chip\" [class.active]=\"d.event === 'Enrollment Complete'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'dep-event-' + d.id\" \n                      value=\"Enrollment Complete\" \n                      [checked]=\"d.event === 'Enrollment Complete'\"\n                      (change)=\"d.event = 'Enrollment Complete'; onDependencyChange(d)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Enrollment Complete</span>\n                  </label>\n                </div>\n\n                <!-- Number of Subjects Input -->\n                <div class=\"event-subjects-row\" *ngIf=\"d.event !== 'Enrollment Complete'\">\n                  <label class=\"sub-label\">Required Subjects Count</label>\n                  <input \n                    type=\"number\" \n                    [(ngModel)]=\"d.eventSubjectCount\" \n                    (ngModelChange)=\"onDependencyChange(d)\"\n                    placeholder=\"e.g. 6\" \n                    min=\"1\"\n                    [disabled]=\"readonly\"\n                  />\n                </div>\n              </div>\n\n              <!-- Dependent Cohort(s) -->\n              <div class=\"v-input-group\">\n                <label>Dependent Cohort(s)</label>\n                <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n                  <label \n                    *ngFor=\"let c of cohorts()\" \n                    class=\"cohort-chip-checkbox\" \n                    [class.checked]=\"isCohortDependent(d.id, c.id)\"\n                    [title]=\"'Link ' + c.name + ' as dependent cohort'\"\n                  >\n                    <input \n                      type=\"checkbox\" \n                      [checked]=\"isCohortDependent(d.id, c.id)\"\n                      (change)=\"toggleDependentCohort(d.id, c.id)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n                    <span class=\"chip-name\">{{ c.name }}</span>\n                  </label>\n                </div>\n                <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas</span>\n              </div>\n\n              <!-- Color Palette (Default Black) -->\n              <div class=\"v-input-group\" *ngIf=\"!readonly\">\n                <label>Color (Default Black)</label>\n                <div class=\"color-palette mini-vertical\">\n                  <button\n                    type=\"button\"\n                    *ngFor=\"let col of themeColors\"\n                    class=\"color-dot\"\n                    [style.background]=\"col.hex\"\n                    [class.active]=\"(d.color || '#000000') === col.hex\"\n                    (click)=\"setDependencyColor(d, col.hex)\"\n                    [title]=\"col.name\"\n                  ></button>\n                </div>\n              </div>\n\n              <!-- Description Log / Notes -->\n              <div class=\"v-input-group\">\n                <label>Description Log / Delay Rules</label>\n                <textarea \n                  rows=\"2\"\n                  [(ngModel)]=\"d.description\" \n                  (ngModelChange)=\"onDependencyChange(d)\"\n                  placeholder=\"Prerequisite conditions, parent/child criteria or delay rules...\"\n                  [disabled]=\"readonly\"\n                ></textarea>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"empty-hint\" *ngIf=\"dependencies().length === 0\">\n          No dependencies yet. Click <strong>+ Add Delay</strong> above.\n        </div>\n      </div>\n    </div>\n\n    <!-- ==================== TAB 2: EDIT SELECTED NODE / CONNECTION ==================== -->\n    <div *ngIf=\"activeTab() === 'details'\" class=\"details-container\">\n      <!-- COHORT EDIT FORM -->\n      <div *ngIf=\"isCohort\" class=\"form-container\">\n        <!-- Cohort Name -->\n        <div class=\"form-group\">\n          <label>Cohort Name</label>\n          <input \n            type=\"text\" \n            [(ngModel)]=\"cohortNode.name\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"e.g. Cohort A\" \n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <!-- Cohort Level (Radio: Worldwide | Country) -->\n        <div class=\"form-group\">\n          <label>Cohort Level</label>\n          <div class=\"radio-row\">\n            <label class=\"radio-chip\" [class.active]=\"(cohortNode.cohortLevel || 'Worldwide') === 'Worldwide'\">\n              <input \n                type=\"radio\" \n                [name]=\"'cohort-level-details'\" \n                value=\"Worldwide\" \n                [checked]=\"(cohortNode.cohortLevel || 'Worldwide') === 'Worldwide'\"\n                (change)=\"cohortNode.cohortLevel = 'Worldwide'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Worldwide</span>\n            </label>\n            <label class=\"radio-chip\" [class.active]=\"cohortNode.cohortLevel === 'Country'\">\n              <input \n                type=\"radio\" \n                [name]=\"'cohort-level-details'\" \n                value=\"Country\" \n                [checked]=\"cohortNode.cohortLevel === 'Country'\"\n                (change)=\"cohortNode.cohortLevel = 'Country'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Country</span>\n            </label>\n          </div>\n        </div>\n\n        <!-- Randomization Target & Screening Period -->\n        <div class=\"form-row-2col\">\n          <div class=\"form-group\">\n            <label>Randomization Target</label>\n            <div class=\"n-input-wrapper\">\n              <span class=\"n-prefix\">N=</span>\n              <input \n                type=\"number\" \n                [(ngModel)]=\"cohortNode.randomizationTarget\" \n                (ngModelChange)=\"cohortNode.subjects = cohortNode.randomizationTarget || cohortNode.subjects; onFieldChange()\"\n                min=\"1\" \n                max=\"10000\"\n                placeholder=\"20\"\n                [disabled]=\"readonly\"\n              />\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label>Screening Period</label>\n            <div class=\"delay-input-wrapper\">\n              <input \n                type=\"number\" \n                [(ngModel)]=\"cohortNode.screeningPeriod\" \n                (ngModelChange)=\"onFieldChange()\"\n                min=\"0\" \n                max=\"365\"\n                placeholder=\"14\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"days-suffix\">days</span>\n            </div>\n          </div>\n        </div>\n\n        <!-- Target Last Subject Randomized -->\n        <div class=\"form-group\">\n          <label>Target Last Subject Randomized</label>\n          <input \n            type=\"date\" \n            [(ngModel)]=\"cohortNode.targetLastSubjectRandomized\" \n            (ngModelChange)=\"onFieldChange()\"\n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <!-- Color Coding (Name color & log color) -->\n        <div class=\"form-group\" *ngIf=\"!readonly\">\n          <label>Name Color (Default Black)</label>\n          <div class=\"color-palette\">\n            <button\n              type=\"button\"\n              *ngFor=\"let c of themeColors\"\n              class=\"color-dot\"\n              [style.background]=\"c.hex\"\n              [class.active]=\"(cohortNode.color || '#000000') === c.hex\"\n              (click)=\"cohortNode.color = c.hex; onFieldChange()\"\n              [title]=\"c.name\"\n            ></button>\n          </div>\n        </div>\n\n        <!-- Description Log -->\n        <div class=\"form-group\">\n          <label>Description Log / Inclusion Criteria</label>\n          <textarea \n            rows=\"3\" \n            [(ngModel)]=\"cohortNode.description\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"Add details, criteria, or description log for this cohort...\"\n            [disabled]=\"readonly\"\n          ></textarea>\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentNode()\">\n            Delete Cohort\n          </button>\n        </div>\n      </div>\n\n      <!-- DEPENDENCY EDIT FORM -->\n      <div *ngIf=\"isDependency\" class=\"form-container\">\n        <!-- Dependency Label & Minimal Delay -->\n        <div class=\"form-row-2col\">\n          <div class=\"form-group\">\n            <label>Dependency Label</label>\n            <input \n              type=\"text\" \n              [(ngModel)]=\"dependencyNode.name\" \n              (ngModelChange)=\"onFieldChange()\"\n              placeholder=\"e.g. Safety Delay, Washout\" \n              [disabled]=\"readonly\"\n            />\n          </div>\n\n          <div class=\"form-group\">\n            <label>Minimal Delay</label>\n            <div class=\"delay-input-wrapper\">\n              <input \n                type=\"number\" \n                [(ngModel)]=\"dependencyNode.days\" \n                (ngModelChange)=\"onFieldChange()\"\n                min=\"0\" \n                max=\"365\"\n                placeholder=\"14\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"days-suffix\">days</span>\n            </div>\n          </div>\n        </div>\n\n        <!-- Preceding Cohort(s) -->\n        <div class=\"form-group\">\n          <label>Preceding Cohort(s)</label>\n          <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n            <label \n              *ngFor=\"let c of cohorts()\" \n              class=\"cohort-chip-checkbox\" \n              [class.checked]=\"isCohortPreceding(dependencyNode.id, c.id)\"\n              [title]=\"'Link ' + c.name + ' as preceding cohort'\"\n            >\n              <input \n                type=\"checkbox\" \n                [checked]=\"isCohortPreceding(dependencyNode.id, c.id)\"\n                (change)=\"togglePrecedingCohort(dependencyNode.id, c.id)\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n              <span class=\"chip-name\">{{ c.name }}</span>\n            </label>\n          </div>\n          <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas.</span>\n        </div>\n\n        <!-- Event Gate (Radio: Number of Subjects | Enrollment Complete) -->\n        <div class=\"form-group\">\n          <label>Event Gate</label>\n          <div class=\"radio-row\">\n            <label class=\"radio-chip\" [class.active]=\"dependencyNode.event !== 'Enrollment Complete'\">\n              <input \n                type=\"radio\" \n                [name]=\"'dep-event-details'\" \n                value=\"Number of Subjects\" \n                [checked]=\"dependencyNode.event !== 'Enrollment Complete'\"\n                (change)=\"dependencyNode.event = 'Number of Subjects'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Number of Subjects</span>\n            </label>\n            <label class=\"radio-chip\" [class.active]=\"dependencyNode.event === 'Enrollment Complete'\">\n              <input \n                type=\"radio\" \n                [name]=\"'dep-event-details'\" \n                value=\"Enrollment Complete\" \n                [checked]=\"dependencyNode.event === 'Enrollment Complete'\"\n                (change)=\"dependencyNode.event = 'Enrollment Complete'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Enrollment Complete</span>\n            </label>\n          </div>\n\n          <!-- Required Subjects Count Input -->\n          <div class=\"event-subjects-row\" *ngIf=\"dependencyNode.event !== 'Enrollment Complete'\">\n            <label class=\"sub-label\">Required Subjects Count</label>\n            <input \n              type=\"number\" \n              [(ngModel)]=\"dependencyNode.eventSubjectCount\" \n              (ngModelChange)=\"onFieldChange()\"\n              placeholder=\"e.g. 6\" \n              min=\"1\"\n              [disabled]=\"readonly\"\n            />\n          </div>\n        </div>\n\n        <!-- Dependent Cohort(s) -->\n        <div class=\"form-group\">\n          <label>Dependent Cohort(s)</label>\n          <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n            <label \n              *ngFor=\"let c of cohorts()\" \n              class=\"cohort-chip-checkbox\" \n              [class.checked]=\"isCohortDependent(dependencyNode.id, c.id)\"\n              [title]=\"'Link ' + c.name + ' as dependent cohort'\"\n            >\n              <input \n                type=\"checkbox\" \n                [checked]=\"isCohortDependent(dependencyNode.id, c.id)\"\n                (change)=\"toggleDependentCohort(dependencyNode.id, c.id)\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n              <span class=\"chip-name\">{{ c.name }}</span>\n            </label>\n          </div>\n          <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas.</span>\n        </div>\n\n        <!-- Color Coding (Default Black) -->\n        <div class=\"form-group\" *ngIf=\"!readonly\">\n          <label>Color (Default Black)</label>\n          <div class=\"color-palette\">\n            <button\n              type=\"button\"\n              *ngFor=\"let c of themeColors\"\n              class=\"color-dot\"\n              [style.background]=\"c.hex\"\n              [class.active]=\"(dependencyNode.color || '#000000') === c.hex\"\n              (click)=\"dependencyNode.color = c.hex; onFieldChange()\"\n              [title]=\"c.name\"\n            ></button>\n          </div>\n        </div>\n\n        <!-- Description Log -->\n        <div class=\"form-group\">\n          <label>Description Log / Notes</label>\n          <textarea \n            rows=\"3\" \n            [(ngModel)]=\"dependencyNode.description\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"Add delay rule, prerequisite or parent/child requirements...\"\n            [disabled]=\"readonly\"\n          ></textarea>\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentNode()\">\n            Delete Dependency\n          </button>\n        </div>\n      </div>\n\n      <!-- CONNECTION EDIT FORM -->\n      <div *ngIf=\"connection\" class=\"form-container\">\n        <div class=\"form-group\">\n          <label>Wire Label (Optional)</label>\n          <input \n            type=\"text\" \n            [(ngModel)]=\"connection.label\" \n            (ngModelChange)=\"onConnectionFieldChange()\"\n            placeholder=\"e.g. 1:1, Escalate\" \n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentConnection()\">\n            Delete Connection\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%;height:100%}.inspector-drawer{width:100%;height:100%;background:#fff;display:flex;flex-direction:column;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;color:#1e293b}.drawer-header{padding:10px 14px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;gap:8px}.drawer-header .header-left{display:flex;align-items:center;gap:8px;overflow:hidden;flex:1}.drawer-header .panel-header-title{font-size:13px;font-weight:700;color:#0f172a;letter-spacing:-.2px}.drawer-header .btn-show-all-blocks{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #cbd5e1;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;color:#0284c7;cursor:pointer;box-shadow:0 1px 2px #0000000d;transition:all .15s ease}.drawer-header .btn-show-all-blocks:hover{background:#f0f9ff;border-color:#0284c7;color:#0369a1}.drawer-header .btn-show-all-blocks svg{flex-shrink:0}.drawer-header .panel-details-subtitle{font-size:12px;font-weight:600;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px}.drawer-header .close-btn{background:none;border:none;font-size:20px;color:#94a3b8;cursor:pointer;padding:0 4px;line-height:1}.drawer-header .close-btn:hover{color:#0f172a}.drawer-body{flex:1;overflow-y:auto;padding:16px}.overview-container{display:flex;flex-direction:column;gap:14px}.all-blocks-switcher{display:flex;gap:6px;padding:4px;background:#f1f5f9;border-radius:8px;border:1px solid #e2e8f0}.all-blocks-switcher .switcher-btn{flex:1;display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:8px 12px;background:transparent;border:1px solid transparent;border-radius:6px;font-size:12px;font-weight:600;color:#64748b;cursor:pointer;transition:all .15s ease}.all-blocks-switcher .switcher-btn .switcher-dot{width:7px;height:7px;border-radius:50%;background:#94a3b8}.all-blocks-switcher .switcher-btn .switcher-dot.cohort{background:#0284c7}.all-blocks-switcher .switcher-btn .switcher-dot.dep{background:#000}.all-blocks-switcher .switcher-btn .switcher-badge{font-size:10px;font-weight:700;background:#e0f2fe;color:#0369a1;padding:1px 6px;border-radius:10px}.all-blocks-switcher .switcher-btn:hover{color:#0f172a;background:#ffffffb3}.all-blocks-switcher .switcher-btn.active{background:#fff;color:#0f172a;box-shadow:0 1px 3px #00000014}.all-blocks-switcher .switcher-btn.active.cohort-btn{border-color:#bae6fd;color:#0284c7}.all-blocks-switcher .switcher-btn.active.dep-btn{border-color:#cbd5e1;color:#000}.overview-section{display:flex;flex-direction:column;gap:10px}.overview-section .section-title-row{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e2e8f0;padding-bottom:6px}.overview-section .section-title-group{display:flex;align-items:baseline;gap:8px}.overview-section .section-title{font-size:12px;font-weight:700;color:#334155;text-transform:uppercase;letter-spacing:.5px}.overview-section .section-sub{font-size:11px;font-weight:600;color:#0284c7}.overview-section .btn-section-add{background:none;border:1px solid #cbd5e1;padding:4px 10px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;transition:all .15s ease}.overview-section .btn-section-add.cohort{color:#0284c7;border-color:#bae6fd;background:#f0f9ff}.overview-section .btn-section-add.cohort:hover{background:#e0f2fe}.overview-section .btn-section-add.dep{color:#0f766e;border-color:#99f6e4;background:#f0fdfa}.overview-section .btn-section-add.dep:hover{background:#ccfbf1}.overview-section .overview-cards-list.horizontal-cards-list{display:flex;flex-direction:column;gap:10px}.overview-cards-list.vertical-cards-list{display:flex;flex-direction:column;gap:14px}.batch-vertical-card{display:flex;flex-direction:column;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #0284c7;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px #0000000a;transition:all .15s ease}.batch-vertical-card:hover{border-color:#cbd5e1;box-shadow:0 3px 8px #00000014}.batch-vertical-card.dep-v-card{border-left:4px solid #000000}.batch-vertical-card .v-card-header{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#f8fafc;border-bottom:1px solid #f1f5f9;gap:8px}.batch-vertical-card .v-card-header .header-left{display:flex;align-items:center;gap:8px;overflow:hidden;min-width:0}.batch-vertical-card .v-card-header .header-right{display:flex;align-items:center;gap:6px;flex-shrink:0}.batch-vertical-card .v-card-header .index-badge{font-size:11px;font-weight:700;color:#0369a1;background:#e0f2fe;padding:2px 6px;border-radius:4px;flex-shrink:0}.batch-vertical-card .v-card-header .index-badge.dep{background:#f1f5f9;color:#1e293b}.batch-vertical-card .v-card-header .card-headline{font-size:13px;font-weight:700;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}.batch-vertical-card .v-card-header .card-headline.dep{color:#000}.batch-vertical-card .v-card-header .subjects-pill{font-size:11px;font-weight:700;background:#ecfdf5;color:#047857;border:1px solid #a7f3d0;padding:1px 7px;border-radius:12px;white-space:nowrap}.batch-vertical-card .v-card-header .delay-pill{font-size:11px;font-weight:700;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;padding:1px 7px;border-radius:12px;white-space:nowrap}.batch-vertical-card .v-card-header .dep-icon-preview{width:22px;height:22px;border-radius:50%;background:#f8fafc;border:1px solid #e2e8f0;color:#000;display:flex;align-items:center;justify-content:center;flex-shrink:0}.batch-vertical-card .v-card-header .dep-icon-preview svg{width:13px;height:13px}.batch-vertical-card .v-card-header .size-indicator-badge{font-size:10px;font-weight:600;color:#64748b;background:#fff;border:1px solid #e2e8f0;padding:2px 6px;border-radius:4px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;white-space:nowrap}.batch-vertical-card .v-card-header .btn-card-reset{background:#fff;border:1px solid #cbd5e1;color:#475569;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;transition:all .15s ease}.batch-vertical-card .v-card-header .btn-card-reset:hover{background:#f1f5f9;color:#0f172a;border-color:#94a3b8}.batch-vertical-card .v-card-header .btn-card-delete{background:none;border:1px solid transparent;border-radius:4px;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:17px;color:#94a3b8;cursor:pointer;line-height:1;transition:all .15s ease}.batch-vertical-card .v-card-header .btn-card-delete:hover{color:#ef4444;background:#fef2f2;border-color:#fecaca}.batch-vertical-card .v-card-body{display:flex;flex-direction:column;gap:10px;padding:12px}.batch-vertical-card .v-input-grid.two-col{display:grid;grid-template-columns:1fr 120px;gap:10px}.batch-vertical-card .v-input-group{display:flex;flex-direction:column;gap:4px}.batch-vertical-card .v-input-group label{font-size:10px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.3px}.batch-vertical-card .v-input-group input[type=text],.batch-vertical-card .v-input-group input[type=number],.batch-vertical-card .v-input-group textarea{padding:6px 9px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;color:#0f172a;background:#fff;box-sizing:border-box;font-family:inherit;outline:none;transition:border-color .15s ease,box-shadow .15s ease}.batch-vertical-card .v-input-group input[type=text]:focus,.batch-vertical-card .v-input-group input[type=number]:focus,.batch-vertical-card .v-input-group textarea:focus{border-color:#0284c7;box-shadow:0 0 0 2px #0284c71f}.batch-vertical-card .v-input-group input[type=text]:disabled,.batch-vertical-card .v-input-group input[type=number]:disabled,.batch-vertical-card .v-input-group textarea:disabled{background:#f8fafc;color:#94a3b8;cursor:not-allowed}.batch-vertical-card .v-input-group input[type=text]{font-weight:600}.batch-vertical-card .v-input-group textarea{resize:vertical;min-height:44px}.batch-vertical-card .v-input-group .n-input-wrapper{display:flex;align-items:center;position:relative}.batch-vertical-card .v-input-group .n-input-wrapper .n-prefix{position:absolute;left:8px;font-size:11px;font-weight:700;color:#059669;pointer-events:none}.batch-vertical-card .v-input-group .n-input-wrapper input{width:100%;padding-left:28px;font-weight:700;color:#059669}.batch-vertical-card .v-input-group .delay-input-wrapper{display:flex;align-items:center;position:relative}.batch-vertical-card .v-input-group .delay-input-wrapper input{width:100%;padding-right:36px;font-weight:700;color:#0f766e}.batch-vertical-card .v-input-group .delay-input-wrapper .days-suffix{position:absolute;right:8px;font-size:10px;font-weight:600;color:#64748b;pointer-events:none}.batch-vertical-card .color-palette.mini-vertical{display:flex;gap:7px;align-items:center;flex-wrap:wrap}.batch-vertical-card .color-palette.mini-vertical .color-dot{width:18px;height:18px;border-radius:50%;border:2px solid #ffffff;cursor:pointer;padding:0;box-shadow:0 1px 3px #0003;transition:transform .12s ease}.batch-vertical-card .color-palette.mini-vertical .color-dot:hover{transform:scale(1.18)}.batch-vertical-card .color-palette.mini-vertical .color-dot.active{box-shadow:0 0 0 2px #0f172a;transform:scale(1.15)}.batch-vertical-card .icon-gallery.mini-vertical{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini{width:28px;height:28px;padding:3px;border:1px solid #e2e8f0;border-radius:5px;background:#fff;color:#64748b;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s ease}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini:hover{border-color:#0d9488;color:#0d9488;background:#f0fdfa}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini.active{border-color:#0d9488;background:#ccfbf1;color:#0f766e}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini svg{width:15px;height:15px}.empty-hint{font-size:11px;color:#94a3b8;font-style:italic;padding:8px 0}.details-container{display:flex;flex-direction:column;gap:12px}.back-link-row{margin-bottom:4px}.back-link-row .btn-back{background:none;border:none;color:#0284c7;font-size:11px;font-weight:600;cursor:pointer;padding:0}.back-link-row .btn-back:hover{text-decoration:underline}.form-container{display:flex;flex-direction:column;gap:12px}.dim-inputs-row{display:flex;align-items:center;gap:8px}.dim-inputs-row .dim-field{display:flex;align-items:center;gap:4px}.dim-inputs-row .dim-field .dim-label{font-size:11px;font-weight:700;color:#64748b}.dim-inputs-row .dim-field input{width:72px;padding:5px 6px;font-size:12px;border:1px solid #cbd5e1;border-radius:5px;font-family:inherit}.dim-inputs-row .btn-reset-dim{background:#f8fafc;border:1px solid #cbd5e1;color:#475569;padding:5px 10px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;transition:all .15s ease}.dim-inputs-row .btn-reset-dim:hover{background:#f1f5f9;color:#0f172a;border-color:#94a3b8}.form-group{display:flex;flex-direction:column;gap:4px}.form-group.form-check-row .check-label{display:flex;align-items:center;gap:6px;font-size:12px;text-transform:none;cursor:pointer;color:#334155}.form-group.form-check-row .check-label input[type=checkbox]{width:auto;cursor:pointer}.form-group label{font-size:11px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.3px}.form-group input[type=text],.form-group input[type=number],.form-group textarea{width:100%;padding:6px 10px;font-size:13px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#1e293b;box-sizing:border-box}.form-group input[type=text]:focus,.form-group input[type=number]:focus,.form-group textarea:focus{outline:none;border-color:#0284c7;box-shadow:0 0 0 2px #0284c726}.form-group textarea{resize:vertical;font-family:inherit}.color-palette{display:flex;gap:6px;flex-wrap:wrap}.color-palette .color-dot{width:22px;height:22px;border-radius:50%;border:2px solid #ffffff;cursor:pointer;box-shadow:0 1px 3px #00000040;transition:transform .15s ease}.color-palette .color-dot:hover{transform:scale(1.15)}.color-palette .color-dot.active{box-shadow:0 0 0 2px #0284c7;transform:scale(1.15)}.icon-gallery{display:flex;gap:6px;flex-wrap:wrap}.icon-gallery .icon-gallery-btn{width:32px;height:32px;display:flex;align-items:center;justify-content:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;color:#475569;transition:all .15s ease}.icon-gallery .icon-gallery-btn:hover{border-color:#0d9488;color:#0d9488;background:#f0fdfa}.icon-gallery .icon-gallery-btn.active{border-color:#0d9488;background:#ccfbf1;color:#0f766e}.drawer-actions{margin-top:10px;padding-top:12px;border-top:1px solid #e2e8f0}.drawer-actions .btn-delete{width:100%;padding:7px;font-size:12px;font-weight:600;background:#fef2f2;color:#ef4444;border:1px solid #fecaca;border-radius:6px;cursor:pointer}.drawer-actions .btn-delete:hover{background:#fee2e2}.radio-row{display:flex;gap:8px;margin-top:4px}.radio-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:6px;background:#f8fafc;border:1px solid #e2e8f0;font-size:12px;font-weight:600;color:#475569;cursor:pointer;transition:all .15s ease;-webkit-user-select:none;user-select:none}.radio-chip input[type=radio]{margin:0;cursor:pointer;accent-color:#0284c7}.radio-chip:hover{background:#f1f5f9;color:#0f172a;border-color:#cbd5e1}.radio-chip.active{background:#f0f9ff;border-color:#0284c7;color:#0284c7}.form-row-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px}.form-row-2col .form-group{margin-bottom:0}.event-subjects-row{display:flex;align-items:center;gap:8px;margin-top:8px;padding:6px 10px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px}.event-subjects-row .sub-label{font-size:11px;font-weight:600;color:#475569;white-space:nowrap;margin-bottom:0}.event-subjects-row input[type=number]{width:80px;padding:4px 8px;font-size:12px;font-weight:600;border:1px solid #cbd5e1;border-radius:4px;background:#fff;color:#0f172a}.cohort-selection-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}.cohort-chip-checkbox{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:6px;background:#f8fafc;border:1px solid #e2e8f0;font-size:11px;font-weight:600;color:#334155;cursor:pointer;transition:all .15s ease;-webkit-user-select:none;user-select:none}.cohort-chip-checkbox input[type=checkbox]{margin:0;cursor:pointer;accent-color:#0284c7}.cohort-chip-checkbox .chip-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}.cohort-chip-checkbox .chip-name{white-space:nowrap}.cohort-chip-checkbox:hover{background:#f1f5f9;border-color:#cbd5e1}.cohort-chip-checkbox.checked{background:#f0f9ff;border-color:#0284c7;color:#0369a1}.no-cohorts-note{font-size:11px;color:#94a3b8;font-style:italic;display:block;margin-top:4px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.MinValidator, selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]", inputs: ["min"] }, { kind: "directive", type: i2.MaxValidator, selector: "input[type=number][max][formControlName],input[type=number][max][formControl],input[type=number][max][ngModel]", inputs: ["max"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: InspectorPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-inspector-panel', standalone: true, imports: [CommonModule, FormsModule], template: "<div class=\"inspector-drawer\">\n  <!-- Clean Drawer Header -->\n  <div class=\"drawer-header\">\n    <div class=\"header-left\">\n      <!-- In Overview mode: Show clean Title -->\n      <span class=\"panel-header-title\" *ngIf=\"activeTab() === 'overview'\">\n        All Blocks ({{ cohorts().length + dependencies().length }})\n      </span>\n\n      <!-- In Single Section Details mode: Clean button to show All Blocks -->\n      <button \n        type=\"button\" \n        class=\"btn-show-all-blocks\" \n        *ngIf=\"activeTab() === 'details'\"\n        (click)=\"setTab('overview')\"\n        title=\"Show all cohorts and dependencies together\"\n      >\n        <svg viewBox=\"0 0 24 24\" width=\"13\" height=\"13\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n          <line x1=\"19\" y1=\"12\" x2=\"5\" y2=\"12\"></line>\n          <polyline points=\"12 19 5 12 12 5\"></polyline>\n        </svg>\n        <span>All Blocks ({{ cohorts().length + dependencies().length }})</span>\n      </button>\n\n      <span class=\"panel-details-subtitle\" *ngIf=\"activeTab() === 'details'\">\n        &bull; {{ isCohort ? (cohortNode.name || 'Cohort') : isDependency ? (dependencyNode.name || 'Delay') : 'Connection' }}\n      </span>\n    </div>\n\n    <button type=\"button\" class=\"close-btn\" (click)=\"close.emit()\" title=\"Close panel\">\n      &times;\n    </button>\n  </div>\n\n  <!-- Drawer Body -->\n  <div class=\"drawer-body\">\n\n    <!-- ==================== TAB 1: ALL BLOCKS SIMULTANEOUS BATCH EDITING ==================== -->\n    <div *ngIf=\"activeTab() === 'overview'\" class=\"overview-container\">\n      \n      <!-- Section Switcher: Switch between Cohorts and Dependencies -->\n      <div class=\"all-blocks-switcher\">\n        <button \n          type=\"button\" \n          class=\"switcher-btn cohort-btn\"\n          [class.active]=\"allBlocksSection() === 'cohorts'\"\n          (click)=\"setAllBlocksSection('cohorts')\"\n        >\n          <span class=\"switcher-dot cohort\"></span>\n          <span>Cohorts ({{ cohorts().length }})</span>\n          <span class=\"switcher-badge\" *ngIf=\"cohorts().length > 0\">N={{ totalRandomizedSubjects() }}</span>\n        </button>\n\n        <button \n          type=\"button\" \n          class=\"switcher-btn dep-btn\"\n          [class.active]=\"allBlocksSection() === 'dependencies'\"\n          (click)=\"setAllBlocksSection('dependencies')\"\n        >\n          <span class=\"switcher-dot dep\"></span>\n          <span>Dependencies ({{ dependencies().length }})</span>\n        </button>\n      </div>\n\n      <!-- SECTION 1: COHORTS (VERTICAL MODE IN SEQUENCE LEFT TO RIGHT) -->\n      <div class=\"overview-section\" *ngIf=\"allBlocksSection() === 'cohorts'\">\n        <div class=\"section-title-row\">\n          <div class=\"section-title-group\">\n            <span class=\"section-title\">Cohorts</span>\n            <span class=\"section-sub\" *ngIf=\"cohorts().length > 0\">\n              {{ cohorts().length }} Cohort{{ cohorts().length === 1 ? '' : 's' }} &bull; Total Randomized N={{ totalRandomizedSubjects() }}\n            </span>\n          </div>\n        </div>\n\n        <div class=\"overview-cards-list vertical-cards-list\" *ngIf=\"cohorts().length > 0\">\n          <div \n            class=\"batch-vertical-card cohort-v-card\" \n            *ngFor=\"let c of cohorts(); let i = index\"\n            [style.borderLeftColor]=\"c.color || '#000000'\"\n          >\n            <!-- Card Header -->\n            <div class=\"v-card-header\">\n              <div class=\"header-left\">\n                <span class=\"index-badge\">#{{ i + 1 }}</span>\n                <span class=\"card-headline\" [style.color]=\"c.color || '#000000'\">\n                  {{ c.name }}\n                </span>\n                <span class=\"subjects-pill\">N={{ c.randomizationTarget || c.subjects }}</span>\n              </div>\n\n              <div class=\"header-right\" *ngIf=\"!readonly\">\n                <button \n                  type=\"button\" \n                  class=\"btn-card-delete\" \n                  (click)=\"deleteCohort(c.id)\"\n                  title=\"Delete this cohort\"\n                >\n                  &times;\n                </button>\n              </div>\n            </div>\n\n            <!-- Card Body in Vertical Mode -->\n            <div class=\"v-card-body\">\n              <!-- Cohort Name -->\n              <div class=\"v-input-group\">\n                <label>Cohort Name</label>\n                <input \n                  type=\"text\" \n                  [(ngModel)]=\"c.name\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  [style.color]=\"c.color || '#000000'\"\n                  placeholder=\"e.g. Cohort A\" \n                  [disabled]=\"readonly\"\n                />\n              </div>\n\n              <!-- Cohort Level (Radio: Worldwide | Country) -->\n              <div class=\"v-input-group\">\n                <label>Cohort Level</label>\n                <div class=\"radio-row\">\n                  <label class=\"radio-chip\" [class.active]=\"(c.cohortLevel || 'Worldwide') === 'Worldwide'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'cohort-level-' + c.id\" \n                      value=\"Worldwide\" \n                      [checked]=\"(c.cohortLevel || 'Worldwide') === 'Worldwide'\"\n                      (change)=\"c.cohortLevel = 'Worldwide'; onCohortChange(c)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Worldwide</span>\n                  </label>\n                  <label class=\"radio-chip\" [class.active]=\"c.cohortLevel === 'Country'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'cohort-level-' + c.id\" \n                      value=\"Country\" \n                      [checked]=\"c.cohortLevel === 'Country'\"\n                      (change)=\"c.cohortLevel = 'Country'; onCohortChange(c)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Country</span>\n                  </label>\n                </div>\n              </div>\n\n              <!-- Randomization Target & Screening Period -->\n              <div class=\"v-input-grid two-col\">\n                <div class=\"v-input-group\">\n                  <label>Randomization Target</label>\n                  <div class=\"n-input-wrapper\">\n                    <span class=\"n-prefix\">N=</span>\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"c.randomizationTarget\" \n                      (ngModelChange)=\"c.subjects = c.randomizationTarget || c.subjects; onCohortChange(c)\"\n                      min=\"1\" \n                      max=\"10000\"\n                      placeholder=\"20\"\n                      [disabled]=\"readonly\"\n                    />\n                  </div>\n                </div>\n\n                <div class=\"v-input-group\">\n                  <label>Screening Period</label>\n                  <div class=\"delay-input-wrapper\">\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"c.screeningPeriod\" \n                      (ngModelChange)=\"onCohortChange(c)\"\n                      min=\"0\" \n                      max=\"365\"\n                      placeholder=\"14\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"days-suffix\">days</span>\n                  </div>\n                </div>\n              </div>\n\n              <!-- Target Last Subject Randomized -->\n              <div class=\"v-input-group\">\n                <label>Target Last Subject Randomized</label>\n                <input \n                  type=\"date\" \n                  [(ngModel)]=\"c.targetLastSubjectRandomized\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  [disabled]=\"readonly\"\n                />\n              </div>\n\n              <!-- Color Palette -->\n              <div class=\"v-input-group\" *ngIf=\"!readonly\">\n                <label>Name Color (Default Black)</label>\n                <div class=\"color-palette mini-vertical\">\n                  <button\n                    type=\"button\"\n                    *ngFor=\"let col of themeColors\"\n                    class=\"color-dot\"\n                    [style.background]=\"col.hex\"\n                    [class.active]=\"(c.color || '#000000') === col.hex\"\n                    (click)=\"setCohortColor(c, col.hex)\"\n                    [title]=\"col.name\"\n                  ></button>\n                </div>\n              </div>\n\n              <!-- Description Log / Notes -->\n              <div class=\"v-input-group\">\n                <label>Description Log / Inclusion Criteria</label>\n                <textarea \n                  rows=\"2\"\n                  [(ngModel)]=\"c.description\" \n                  (ngModelChange)=\"onCohortChange(c)\"\n                  placeholder=\"Eligibility criteria or notes for this cohort...\"\n                  [disabled]=\"readonly\"\n                ></textarea>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"empty-hint\" *ngIf=\"cohorts().length === 0\">\n          No cohorts on canvas yet. Click <strong>+ Select Cohort</strong> in the top header to add cohorts.\n        </div>\n      </div>\n\n      <!-- SECTION 2: DEPENDENCIES (VERTICAL MODE IN SEQUENCE LEFT TO RIGHT) -->\n      <div class=\"overview-section\" *ngIf=\"allBlocksSection() === 'dependencies'\">\n        <div class=\"section-title-row\">\n          <div class=\"section-title-group\">\n            <span class=\"section-title\">Dependencies & Delays</span>\n            <span class=\"section-sub\" *ngIf=\"dependencies().length > 0\">\n              {{ dependencies().length }} Delay Block{{ dependencies().length === 1 ? '' : 's' }}\n            </span>\n          </div>\n          <button \n            type=\"button\" \n            class=\"btn-section-add dep\" \n            *ngIf=\"!readonly\"\n            (click)=\"addNewDependency()\" \n            title=\"Add new dependency / delay\"\n          >\n            + Add Delay\n          </button>\n        </div>\n\n        <div class=\"overview-cards-list vertical-cards-list\" *ngIf=\"dependencies().length > 0\">\n          <div \n            class=\"batch-vertical-card dep-v-card\" \n            *ngFor=\"let d of dependencies(); let j = index\"\n            [style.borderLeftColor]=\"d.color || '#000000'\"\n          >\n            <!-- Card Header -->\n            <div class=\"v-card-header\">\n              <div class=\"header-left\">\n                <span class=\"index-badge dep\" [style.color]=\"d.color || '#000000'\">#{{ j + 1 }}</span>\n                <span class=\"dep-icon-preview\" [style.color]=\"d.color || '#000000'\" [innerHTML]=\"getSafeIconById(d.icon)\"></span>\n                <span class=\"card-headline dep\" [style.color]=\"d.color || '#000000'\">{{ d.name }}</span>\n                <span class=\"delay-pill\">{{ d.days }}d delay</span>\n              </div>\n\n              <div class=\"header-right\" *ngIf=\"!readonly\">\n                <button \n                  type=\"button\" \n                  class=\"btn-card-delete\" \n                  (click)=\"deleteDependency(d.id)\"\n                  title=\"Delete this dependency\"\n                >\n                  &times;\n                </button>\n              </div>\n            </div>\n\n            <!-- Card Body in Vertical Mode -->\n            <div class=\"v-card-body\">\n              <div class=\"v-input-grid two-col\">\n                <div class=\"v-input-group\">\n                  <label>Dependency Label</label>\n                  <input \n                    type=\"text\" \n                    [(ngModel)]=\"d.name\" \n                    (ngModelChange)=\"onDependencyChange(d)\"\n                    placeholder=\"e.g. Safety Delay\" \n                    [disabled]=\"readonly\"\n                  />\n                </div>\n\n                <div class=\"v-input-group\">\n                  <label>Minimal Delay</label>\n                  <div class=\"delay-input-wrapper\">\n                    <input \n                      type=\"number\" \n                      [(ngModel)]=\"d.days\" \n                      (ngModelChange)=\"onDependencyChange(d)\"\n                      min=\"0\" \n                      max=\"365\"\n                      placeholder=\"14\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"days-suffix\">days</span>\n                  </div>\n                </div>\n              </div>\n\n              <!-- Preceding Cohort(s) -->\n              <div class=\"v-input-group\">\n                <label>Preceding Cohort(s)</label>\n                <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n                  <label \n                    *ngFor=\"let c of cohorts()\" \n                    class=\"cohort-chip-checkbox\" \n                    [class.checked]=\"isCohortPreceding(d.id, c.id)\"\n                    [title]=\"'Link ' + c.name + ' as preceding cohort'\"\n                  >\n                    <input \n                      type=\"checkbox\" \n                      [checked]=\"isCohortPreceding(d.id, c.id)\"\n                      (change)=\"togglePrecedingCohort(d.id, c.id)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n                    <span class=\"chip-name\">{{ c.name }}</span>\n                  </label>\n                </div>\n                <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas</span>\n              </div>\n\n              <!-- Event Gate (Radio: Number of Subjects | Enrollment Complete) -->\n              <div class=\"v-input-group\">\n                <label>Event Gate</label>\n                <div class=\"radio-row\">\n                  <label class=\"radio-chip\" [class.active]=\"d.event !== 'Enrollment Complete'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'dep-event-' + d.id\" \n                      value=\"Number of Subjects\" \n                      [checked]=\"d.event !== 'Enrollment Complete'\"\n                      (change)=\"d.event = 'Number of Subjects'; onDependencyChange(d)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Number of Subjects</span>\n                  </label>\n                  <label class=\"radio-chip\" [class.active]=\"d.event === 'Enrollment Complete'\">\n                    <input \n                      type=\"radio\" \n                      [name]=\"'dep-event-' + d.id\" \n                      value=\"Enrollment Complete\" \n                      [checked]=\"d.event === 'Enrollment Complete'\"\n                      (change)=\"d.event = 'Enrollment Complete'; onDependencyChange(d)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span>Enrollment Complete</span>\n                  </label>\n                </div>\n\n                <!-- Number of Subjects Input -->\n                <div class=\"event-subjects-row\" *ngIf=\"d.event !== 'Enrollment Complete'\">\n                  <label class=\"sub-label\">Required Subjects Count</label>\n                  <input \n                    type=\"number\" \n                    [(ngModel)]=\"d.eventSubjectCount\" \n                    (ngModelChange)=\"onDependencyChange(d)\"\n                    placeholder=\"e.g. 6\" \n                    min=\"1\"\n                    [disabled]=\"readonly\"\n                  />\n                </div>\n              </div>\n\n              <!-- Dependent Cohort(s) -->\n              <div class=\"v-input-group\">\n                <label>Dependent Cohort(s)</label>\n                <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n                  <label \n                    *ngFor=\"let c of cohorts()\" \n                    class=\"cohort-chip-checkbox\" \n                    [class.checked]=\"isCohortDependent(d.id, c.id)\"\n                    [title]=\"'Link ' + c.name + ' as dependent cohort'\"\n                  >\n                    <input \n                      type=\"checkbox\" \n                      [checked]=\"isCohortDependent(d.id, c.id)\"\n                      (change)=\"toggleDependentCohort(d.id, c.id)\"\n                      [disabled]=\"readonly\"\n                    />\n                    <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n                    <span class=\"chip-name\">{{ c.name }}</span>\n                  </label>\n                </div>\n                <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas</span>\n              </div>\n\n              <!-- Color Palette (Default Black) -->\n              <div class=\"v-input-group\" *ngIf=\"!readonly\">\n                <label>Color (Default Black)</label>\n                <div class=\"color-palette mini-vertical\">\n                  <button\n                    type=\"button\"\n                    *ngFor=\"let col of themeColors\"\n                    class=\"color-dot\"\n                    [style.background]=\"col.hex\"\n                    [class.active]=\"(d.color || '#000000') === col.hex\"\n                    (click)=\"setDependencyColor(d, col.hex)\"\n                    [title]=\"col.name\"\n                  ></button>\n                </div>\n              </div>\n\n              <!-- Description Log / Notes -->\n              <div class=\"v-input-group\">\n                <label>Description Log / Delay Rules</label>\n                <textarea \n                  rows=\"2\"\n                  [(ngModel)]=\"d.description\" \n                  (ngModelChange)=\"onDependencyChange(d)\"\n                  placeholder=\"Prerequisite conditions, parent/child criteria or delay rules...\"\n                  [disabled]=\"readonly\"\n                ></textarea>\n              </div>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"empty-hint\" *ngIf=\"dependencies().length === 0\">\n          No dependencies yet. Click <strong>+ Add Delay</strong> above.\n        </div>\n      </div>\n    </div>\n\n    <!-- ==================== TAB 2: EDIT SELECTED NODE / CONNECTION ==================== -->\n    <div *ngIf=\"activeTab() === 'details'\" class=\"details-container\">\n      <!-- COHORT EDIT FORM -->\n      <div *ngIf=\"isCohort\" class=\"form-container\">\n        <!-- Cohort Name -->\n        <div class=\"form-group\">\n          <label>Cohort Name</label>\n          <input \n            type=\"text\" \n            [(ngModel)]=\"cohortNode.name\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"e.g. Cohort A\" \n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <!-- Cohort Level (Radio: Worldwide | Country) -->\n        <div class=\"form-group\">\n          <label>Cohort Level</label>\n          <div class=\"radio-row\">\n            <label class=\"radio-chip\" [class.active]=\"(cohortNode.cohortLevel || 'Worldwide') === 'Worldwide'\">\n              <input \n                type=\"radio\" \n                [name]=\"'cohort-level-details'\" \n                value=\"Worldwide\" \n                [checked]=\"(cohortNode.cohortLevel || 'Worldwide') === 'Worldwide'\"\n                (change)=\"cohortNode.cohortLevel = 'Worldwide'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Worldwide</span>\n            </label>\n            <label class=\"radio-chip\" [class.active]=\"cohortNode.cohortLevel === 'Country'\">\n              <input \n                type=\"radio\" \n                [name]=\"'cohort-level-details'\" \n                value=\"Country\" \n                [checked]=\"cohortNode.cohortLevel === 'Country'\"\n                (change)=\"cohortNode.cohortLevel = 'Country'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Country</span>\n            </label>\n          </div>\n        </div>\n\n        <!-- Randomization Target & Screening Period -->\n        <div class=\"form-row-2col\">\n          <div class=\"form-group\">\n            <label>Randomization Target</label>\n            <div class=\"n-input-wrapper\">\n              <span class=\"n-prefix\">N=</span>\n              <input \n                type=\"number\" \n                [(ngModel)]=\"cohortNode.randomizationTarget\" \n                (ngModelChange)=\"cohortNode.subjects = cohortNode.randomizationTarget || cohortNode.subjects; onFieldChange()\"\n                min=\"1\" \n                max=\"10000\"\n                placeholder=\"20\"\n                [disabled]=\"readonly\"\n              />\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label>Screening Period</label>\n            <div class=\"delay-input-wrapper\">\n              <input \n                type=\"number\" \n                [(ngModel)]=\"cohortNode.screeningPeriod\" \n                (ngModelChange)=\"onFieldChange()\"\n                min=\"0\" \n                max=\"365\"\n                placeholder=\"14\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"days-suffix\">days</span>\n            </div>\n          </div>\n        </div>\n\n        <!-- Target Last Subject Randomized -->\n        <div class=\"form-group\">\n          <label>Target Last Subject Randomized</label>\n          <input \n            type=\"date\" \n            [(ngModel)]=\"cohortNode.targetLastSubjectRandomized\" \n            (ngModelChange)=\"onFieldChange()\"\n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <!-- Color Coding (Name color & log color) -->\n        <div class=\"form-group\" *ngIf=\"!readonly\">\n          <label>Name Color (Default Black)</label>\n          <div class=\"color-palette\">\n            <button\n              type=\"button\"\n              *ngFor=\"let c of themeColors\"\n              class=\"color-dot\"\n              [style.background]=\"c.hex\"\n              [class.active]=\"(cohortNode.color || '#000000') === c.hex\"\n              (click)=\"cohortNode.color = c.hex; onFieldChange()\"\n              [title]=\"c.name\"\n            ></button>\n          </div>\n        </div>\n\n        <!-- Description Log -->\n        <div class=\"form-group\">\n          <label>Description Log / Inclusion Criteria</label>\n          <textarea \n            rows=\"3\" \n            [(ngModel)]=\"cohortNode.description\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"Add details, criteria, or description log for this cohort...\"\n            [disabled]=\"readonly\"\n          ></textarea>\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentNode()\">\n            Delete Cohort\n          </button>\n        </div>\n      </div>\n\n      <!-- DEPENDENCY EDIT FORM -->\n      <div *ngIf=\"isDependency\" class=\"form-container\">\n        <!-- Dependency Label & Minimal Delay -->\n        <div class=\"form-row-2col\">\n          <div class=\"form-group\">\n            <label>Dependency Label</label>\n            <input \n              type=\"text\" \n              [(ngModel)]=\"dependencyNode.name\" \n              (ngModelChange)=\"onFieldChange()\"\n              placeholder=\"e.g. Safety Delay, Washout\" \n              [disabled]=\"readonly\"\n            />\n          </div>\n\n          <div class=\"form-group\">\n            <label>Minimal Delay</label>\n            <div class=\"delay-input-wrapper\">\n              <input \n                type=\"number\" \n                [(ngModel)]=\"dependencyNode.days\" \n                (ngModelChange)=\"onFieldChange()\"\n                min=\"0\" \n                max=\"365\"\n                placeholder=\"14\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"days-suffix\">days</span>\n            </div>\n          </div>\n        </div>\n\n        <!-- Preceding Cohort(s) -->\n        <div class=\"form-group\">\n          <label>Preceding Cohort(s)</label>\n          <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n            <label \n              *ngFor=\"let c of cohorts()\" \n              class=\"cohort-chip-checkbox\" \n              [class.checked]=\"isCohortPreceding(dependencyNode.id, c.id)\"\n              [title]=\"'Link ' + c.name + ' as preceding cohort'\"\n            >\n              <input \n                type=\"checkbox\" \n                [checked]=\"isCohortPreceding(dependencyNode.id, c.id)\"\n                (change)=\"togglePrecedingCohort(dependencyNode.id, c.id)\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n              <span class=\"chip-name\">{{ c.name }}</span>\n            </label>\n          </div>\n          <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas.</span>\n        </div>\n\n        <!-- Event Gate (Radio: Number of Subjects | Enrollment Complete) -->\n        <div class=\"form-group\">\n          <label>Event Gate</label>\n          <div class=\"radio-row\">\n            <label class=\"radio-chip\" [class.active]=\"dependencyNode.event !== 'Enrollment Complete'\">\n              <input \n                type=\"radio\" \n                [name]=\"'dep-event-details'\" \n                value=\"Number of Subjects\" \n                [checked]=\"dependencyNode.event !== 'Enrollment Complete'\"\n                (change)=\"dependencyNode.event = 'Number of Subjects'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Number of Subjects</span>\n            </label>\n            <label class=\"radio-chip\" [class.active]=\"dependencyNode.event === 'Enrollment Complete'\">\n              <input \n                type=\"radio\" \n                [name]=\"'dep-event-details'\" \n                value=\"Enrollment Complete\" \n                [checked]=\"dependencyNode.event === 'Enrollment Complete'\"\n                (change)=\"dependencyNode.event = 'Enrollment Complete'; onFieldChange()\"\n                [disabled]=\"readonly\"\n              />\n              <span>Enrollment Complete</span>\n            </label>\n          </div>\n\n          <!-- Required Subjects Count Input -->\n          <div class=\"event-subjects-row\" *ngIf=\"dependencyNode.event !== 'Enrollment Complete'\">\n            <label class=\"sub-label\">Required Subjects Count</label>\n            <input \n              type=\"number\" \n              [(ngModel)]=\"dependencyNode.eventSubjectCount\" \n              (ngModelChange)=\"onFieldChange()\"\n              placeholder=\"e.g. 6\" \n              min=\"1\"\n              [disabled]=\"readonly\"\n            />\n          </div>\n        </div>\n\n        <!-- Dependent Cohort(s) -->\n        <div class=\"form-group\">\n          <label>Dependent Cohort(s)</label>\n          <div class=\"cohort-selection-chips\" *ngIf=\"cohorts().length > 0\">\n            <label \n              *ngFor=\"let c of cohorts()\" \n              class=\"cohort-chip-checkbox\" \n              [class.checked]=\"isCohortDependent(dependencyNode.id, c.id)\"\n              [title]=\"'Link ' + c.name + ' as dependent cohort'\"\n            >\n              <input \n                type=\"checkbox\" \n                [checked]=\"isCohortDependent(dependencyNode.id, c.id)\"\n                (change)=\"toggleDependentCohort(dependencyNode.id, c.id)\"\n                [disabled]=\"readonly\"\n              />\n              <span class=\"chip-dot\" [style.background]=\"c.color || '#000000'\"></span>\n              <span class=\"chip-name\">{{ c.name }}</span>\n            </label>\n          </div>\n          <span class=\"no-cohorts-note\" *ngIf=\"cohorts().length === 0\">No cohorts available on canvas.</span>\n        </div>\n\n        <!-- Color Coding (Default Black) -->\n        <div class=\"form-group\" *ngIf=\"!readonly\">\n          <label>Color (Default Black)</label>\n          <div class=\"color-palette\">\n            <button\n              type=\"button\"\n              *ngFor=\"let c of themeColors\"\n              class=\"color-dot\"\n              [style.background]=\"c.hex\"\n              [class.active]=\"(dependencyNode.color || '#000000') === c.hex\"\n              (click)=\"dependencyNode.color = c.hex; onFieldChange()\"\n              [title]=\"c.name\"\n            ></button>\n          </div>\n        </div>\n\n        <!-- Description Log -->\n        <div class=\"form-group\">\n          <label>Description Log / Notes</label>\n          <textarea \n            rows=\"3\" \n            [(ngModel)]=\"dependencyNode.description\" \n            (ngModelChange)=\"onFieldChange()\"\n            placeholder=\"Add delay rule, prerequisite or parent/child requirements...\"\n            [disabled]=\"readonly\"\n          ></textarea>\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentNode()\">\n            Delete Dependency\n          </button>\n        </div>\n      </div>\n\n      <!-- CONNECTION EDIT FORM -->\n      <div *ngIf=\"connection\" class=\"form-container\">\n        <div class=\"form-group\">\n          <label>Wire Label (Optional)</label>\n          <input \n            type=\"text\" \n            [(ngModel)]=\"connection.label\" \n            (ngModelChange)=\"onConnectionFieldChange()\"\n            placeholder=\"e.g. 1:1, Escalate\" \n            [disabled]=\"readonly\"\n          />\n        </div>\n\n        <div class=\"drawer-actions\" *ngIf=\"!readonly\">\n          <button type=\"button\" class=\"btn-delete\" (click)=\"deleteCurrentConnection()\">\n            Delete Connection\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%;height:100%}.inspector-drawer{width:100%;height:100%;background:#fff;display:flex;flex-direction:column;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;color:#1e293b}.drawer-header{padding:10px 14px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;gap:8px}.drawer-header .header-left{display:flex;align-items:center;gap:8px;overflow:hidden;flex:1}.drawer-header .panel-header-title{font-size:13px;font-weight:700;color:#0f172a;letter-spacing:-.2px}.drawer-header .btn-show-all-blocks{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid #cbd5e1;padding:5px 11px;border-radius:6px;font-size:12px;font-weight:600;color:#0284c7;cursor:pointer;box-shadow:0 1px 2px #0000000d;transition:all .15s ease}.drawer-header .btn-show-all-blocks:hover{background:#f0f9ff;border-color:#0284c7;color:#0369a1}.drawer-header .btn-show-all-blocks svg{flex-shrink:0}.drawer-header .panel-details-subtitle{font-size:12px;font-weight:600;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:220px}.drawer-header .close-btn{background:none;border:none;font-size:20px;color:#94a3b8;cursor:pointer;padding:0 4px;line-height:1}.drawer-header .close-btn:hover{color:#0f172a}.drawer-body{flex:1;overflow-y:auto;padding:16px}.overview-container{display:flex;flex-direction:column;gap:14px}.all-blocks-switcher{display:flex;gap:6px;padding:4px;background:#f1f5f9;border-radius:8px;border:1px solid #e2e8f0}.all-blocks-switcher .switcher-btn{flex:1;display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:8px 12px;background:transparent;border:1px solid transparent;border-radius:6px;font-size:12px;font-weight:600;color:#64748b;cursor:pointer;transition:all .15s ease}.all-blocks-switcher .switcher-btn .switcher-dot{width:7px;height:7px;border-radius:50%;background:#94a3b8}.all-blocks-switcher .switcher-btn .switcher-dot.cohort{background:#0284c7}.all-blocks-switcher .switcher-btn .switcher-dot.dep{background:#000}.all-blocks-switcher .switcher-btn .switcher-badge{font-size:10px;font-weight:700;background:#e0f2fe;color:#0369a1;padding:1px 6px;border-radius:10px}.all-blocks-switcher .switcher-btn:hover{color:#0f172a;background:#ffffffb3}.all-blocks-switcher .switcher-btn.active{background:#fff;color:#0f172a;box-shadow:0 1px 3px #00000014}.all-blocks-switcher .switcher-btn.active.cohort-btn{border-color:#bae6fd;color:#0284c7}.all-blocks-switcher .switcher-btn.active.dep-btn{border-color:#cbd5e1;color:#000}.overview-section{display:flex;flex-direction:column;gap:10px}.overview-section .section-title-row{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e2e8f0;padding-bottom:6px}.overview-section .section-title-group{display:flex;align-items:baseline;gap:8px}.overview-section .section-title{font-size:12px;font-weight:700;color:#334155;text-transform:uppercase;letter-spacing:.5px}.overview-section .section-sub{font-size:11px;font-weight:600;color:#0284c7}.overview-section .btn-section-add{background:none;border:1px solid #cbd5e1;padding:4px 10px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;transition:all .15s ease}.overview-section .btn-section-add.cohort{color:#0284c7;border-color:#bae6fd;background:#f0f9ff}.overview-section .btn-section-add.cohort:hover{background:#e0f2fe}.overview-section .btn-section-add.dep{color:#0f766e;border-color:#99f6e4;background:#f0fdfa}.overview-section .btn-section-add.dep:hover{background:#ccfbf1}.overview-section .overview-cards-list.horizontal-cards-list{display:flex;flex-direction:column;gap:10px}.overview-cards-list.vertical-cards-list{display:flex;flex-direction:column;gap:14px}.batch-vertical-card{display:flex;flex-direction:column;background:#fff;border:1px solid #e2e8f0;border-left:4px solid #0284c7;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px #0000000a;transition:all .15s ease}.batch-vertical-card:hover{border-color:#cbd5e1;box-shadow:0 3px 8px #00000014}.batch-vertical-card.dep-v-card{border-left:4px solid #000000}.batch-vertical-card .v-card-header{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#f8fafc;border-bottom:1px solid #f1f5f9;gap:8px}.batch-vertical-card .v-card-header .header-left{display:flex;align-items:center;gap:8px;overflow:hidden;min-width:0}.batch-vertical-card .v-card-header .header-right{display:flex;align-items:center;gap:6px;flex-shrink:0}.batch-vertical-card .v-card-header .index-badge{font-size:11px;font-weight:700;color:#0369a1;background:#e0f2fe;padding:2px 6px;border-radius:4px;flex-shrink:0}.batch-vertical-card .v-card-header .index-badge.dep{background:#f1f5f9;color:#1e293b}.batch-vertical-card .v-card-header .card-headline{font-size:13px;font-weight:700;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px}.batch-vertical-card .v-card-header .card-headline.dep{color:#000}.batch-vertical-card .v-card-header .subjects-pill{font-size:11px;font-weight:700;background:#ecfdf5;color:#047857;border:1px solid #a7f3d0;padding:1px 7px;border-radius:12px;white-space:nowrap}.batch-vertical-card .v-card-header .delay-pill{font-size:11px;font-weight:700;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;padding:1px 7px;border-radius:12px;white-space:nowrap}.batch-vertical-card .v-card-header .dep-icon-preview{width:22px;height:22px;border-radius:50%;background:#f8fafc;border:1px solid #e2e8f0;color:#000;display:flex;align-items:center;justify-content:center;flex-shrink:0}.batch-vertical-card .v-card-header .dep-icon-preview svg{width:13px;height:13px}.batch-vertical-card .v-card-header .size-indicator-badge{font-size:10px;font-weight:600;color:#64748b;background:#fff;border:1px solid #e2e8f0;padding:2px 6px;border-radius:4px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;white-space:nowrap}.batch-vertical-card .v-card-header .btn-card-reset{background:#fff;border:1px solid #cbd5e1;color:#475569;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;transition:all .15s ease}.batch-vertical-card .v-card-header .btn-card-reset:hover{background:#f1f5f9;color:#0f172a;border-color:#94a3b8}.batch-vertical-card .v-card-header .btn-card-delete{background:none;border:1px solid transparent;border-radius:4px;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:17px;color:#94a3b8;cursor:pointer;line-height:1;transition:all .15s ease}.batch-vertical-card .v-card-header .btn-card-delete:hover{color:#ef4444;background:#fef2f2;border-color:#fecaca}.batch-vertical-card .v-card-body{display:flex;flex-direction:column;gap:10px;padding:12px}.batch-vertical-card .v-input-grid.two-col{display:grid;grid-template-columns:1fr 120px;gap:10px}.batch-vertical-card .v-input-group{display:flex;flex-direction:column;gap:4px}.batch-vertical-card .v-input-group label{font-size:10px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.3px}.batch-vertical-card .v-input-group input[type=text],.batch-vertical-card .v-input-group input[type=number],.batch-vertical-card .v-input-group textarea{padding:6px 9px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;color:#0f172a;background:#fff;box-sizing:border-box;font-family:inherit;outline:none;transition:border-color .15s ease,box-shadow .15s ease}.batch-vertical-card .v-input-group input[type=text]:focus,.batch-vertical-card .v-input-group input[type=number]:focus,.batch-vertical-card .v-input-group textarea:focus{border-color:#0284c7;box-shadow:0 0 0 2px #0284c71f}.batch-vertical-card .v-input-group input[type=text]:disabled,.batch-vertical-card .v-input-group input[type=number]:disabled,.batch-vertical-card .v-input-group textarea:disabled{background:#f8fafc;color:#94a3b8;cursor:not-allowed}.batch-vertical-card .v-input-group input[type=text]{font-weight:600}.batch-vertical-card .v-input-group textarea{resize:vertical;min-height:44px}.batch-vertical-card .v-input-group .n-input-wrapper{display:flex;align-items:center;position:relative}.batch-vertical-card .v-input-group .n-input-wrapper .n-prefix{position:absolute;left:8px;font-size:11px;font-weight:700;color:#059669;pointer-events:none}.batch-vertical-card .v-input-group .n-input-wrapper input{width:100%;padding-left:28px;font-weight:700;color:#059669}.batch-vertical-card .v-input-group .delay-input-wrapper{display:flex;align-items:center;position:relative}.batch-vertical-card .v-input-group .delay-input-wrapper input{width:100%;padding-right:36px;font-weight:700;color:#0f766e}.batch-vertical-card .v-input-group .delay-input-wrapper .days-suffix{position:absolute;right:8px;font-size:10px;font-weight:600;color:#64748b;pointer-events:none}.batch-vertical-card .color-palette.mini-vertical{display:flex;gap:7px;align-items:center;flex-wrap:wrap}.batch-vertical-card .color-palette.mini-vertical .color-dot{width:18px;height:18px;border-radius:50%;border:2px solid #ffffff;cursor:pointer;padding:0;box-shadow:0 1px 3px #0003;transition:transform .12s ease}.batch-vertical-card .color-palette.mini-vertical .color-dot:hover{transform:scale(1.18)}.batch-vertical-card .color-palette.mini-vertical .color-dot.active{box-shadow:0 0 0 2px #0f172a;transform:scale(1.15)}.batch-vertical-card .icon-gallery.mini-vertical{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini{width:28px;height:28px;padding:3px;border:1px solid #e2e8f0;border-radius:5px;background:#fff;color:#64748b;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s ease}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini:hover{border-color:#0d9488;color:#0d9488;background:#f0fdfa}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini.active{border-color:#0d9488;background:#ccfbf1;color:#0f766e}.batch-vertical-card .icon-gallery.mini-vertical .icon-gallery-btn.mini svg{width:15px;height:15px}.empty-hint{font-size:11px;color:#94a3b8;font-style:italic;padding:8px 0}.details-container{display:flex;flex-direction:column;gap:12px}.back-link-row{margin-bottom:4px}.back-link-row .btn-back{background:none;border:none;color:#0284c7;font-size:11px;font-weight:600;cursor:pointer;padding:0}.back-link-row .btn-back:hover{text-decoration:underline}.form-container{display:flex;flex-direction:column;gap:12px}.dim-inputs-row{display:flex;align-items:center;gap:8px}.dim-inputs-row .dim-field{display:flex;align-items:center;gap:4px}.dim-inputs-row .dim-field .dim-label{font-size:11px;font-weight:700;color:#64748b}.dim-inputs-row .dim-field input{width:72px;padding:5px 6px;font-size:12px;border:1px solid #cbd5e1;border-radius:5px;font-family:inherit}.dim-inputs-row .btn-reset-dim{background:#f8fafc;border:1px solid #cbd5e1;color:#475569;padding:5px 10px;border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;transition:all .15s ease}.dim-inputs-row .btn-reset-dim:hover{background:#f1f5f9;color:#0f172a;border-color:#94a3b8}.form-group{display:flex;flex-direction:column;gap:4px}.form-group.form-check-row .check-label{display:flex;align-items:center;gap:6px;font-size:12px;text-transform:none;cursor:pointer;color:#334155}.form-group.form-check-row .check-label input[type=checkbox]{width:auto;cursor:pointer}.form-group label{font-size:11px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.3px}.form-group input[type=text],.form-group input[type=number],.form-group textarea{width:100%;padding:6px 10px;font-size:13px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;color:#1e293b;box-sizing:border-box}.form-group input[type=text]:focus,.form-group input[type=number]:focus,.form-group textarea:focus{outline:none;border-color:#0284c7;box-shadow:0 0 0 2px #0284c726}.form-group textarea{resize:vertical;font-family:inherit}.color-palette{display:flex;gap:6px;flex-wrap:wrap}.color-palette .color-dot{width:22px;height:22px;border-radius:50%;border:2px solid #ffffff;cursor:pointer;box-shadow:0 1px 3px #00000040;transition:transform .15s ease}.color-palette .color-dot:hover{transform:scale(1.15)}.color-palette .color-dot.active{box-shadow:0 0 0 2px #0284c7;transform:scale(1.15)}.icon-gallery{display:flex;gap:6px;flex-wrap:wrap}.icon-gallery .icon-gallery-btn{width:32px;height:32px;display:flex;align-items:center;justify-content:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;color:#475569;transition:all .15s ease}.icon-gallery .icon-gallery-btn:hover{border-color:#0d9488;color:#0d9488;background:#f0fdfa}.icon-gallery .icon-gallery-btn.active{border-color:#0d9488;background:#ccfbf1;color:#0f766e}.drawer-actions{margin-top:10px;padding-top:12px;border-top:1px solid #e2e8f0}.drawer-actions .btn-delete{width:100%;padding:7px;font-size:12px;font-weight:600;background:#fef2f2;color:#ef4444;border:1px solid #fecaca;border-radius:6px;cursor:pointer}.drawer-actions .btn-delete:hover{background:#fee2e2}.radio-row{display:flex;gap:8px;margin-top:4px}.radio-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:6px;background:#f8fafc;border:1px solid #e2e8f0;font-size:12px;font-weight:600;color:#475569;cursor:pointer;transition:all .15s ease;-webkit-user-select:none;user-select:none}.radio-chip input[type=radio]{margin:0;cursor:pointer;accent-color:#0284c7}.radio-chip:hover{background:#f1f5f9;color:#0f172a;border-color:#cbd5e1}.radio-chip.active{background:#f0f9ff;border-color:#0284c7;color:#0284c7}.form-row-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px}.form-row-2col .form-group{margin-bottom:0}.event-subjects-row{display:flex;align-items:center;gap:8px;margin-top:8px;padding:6px 10px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px}.event-subjects-row .sub-label{font-size:11px;font-weight:600;color:#475569;white-space:nowrap;margin-bottom:0}.event-subjects-row input[type=number]{width:80px;padding:4px 8px;font-size:12px;font-weight:600;border:1px solid #cbd5e1;border-radius:4px;background:#fff;color:#0f172a}.cohort-selection-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}.cohort-chip-checkbox{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:6px;background:#f8fafc;border:1px solid #e2e8f0;font-size:11px;font-weight:600;color:#334155;cursor:pointer;transition:all .15s ease;-webkit-user-select:none;user-select:none}.cohort-chip-checkbox input[type=checkbox]{margin:0;cursor:pointer;accent-color:#0284c7}.cohort-chip-checkbox .chip-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}.cohort-chip-checkbox .chip-name{white-space:nowrap}.cohort-chip-checkbox:hover{background:#f1f5f9;border-color:#cbd5e1}.cohort-chip-checkbox.checked{background:#f0f9ff;border-color:#0284c7;color:#0369a1}.no-cohorts-note{font-size:11px;color:#94a3b8;font-style:italic;display:block;margin-top:4px}\n"] }]
        }], propDecorators: { node: [{
                type: Input
            }], connection: [{
                type: Input
            }], customIcons: [{
                type: Input
            }], readonly: [{
                type: Input
            }], close: [{
                type: Output
            }] } });

class ToolbarComponent {
    readonly = false;
    addCohort = new EventEmitter();
    addDependency = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ToolbarComponent, isStandalone: true, selector: "lib-toolbar", inputs: { readonly: "readonly" }, outputs: { addCohort: "addCohort", addDependency: "addDependency" }, ngImport: i0, template: "<div class=\"toolbar-container\" *ngIf=\"!readonly\">\n  <button \n    type=\"button\" \n    class=\"btn-tool btn-add-dep\" \n    (click)=\"addDependency.emit()\"\n    title=\"Add a Dependency / Delay component\"\n  >\n    <span class=\"tool-icon circle-icon\"></span>\n    <span>+ Add Dependency</span>\n  </button>\n</div>\n", styles: [":host{display:block}.toolbar-container{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 2px 6px #0000000d;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;position:absolute;top:14px;left:14px;z-index:20}.btn-tool{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .15s ease}.btn-tool .tool-icon{display:inline-block}.btn-tool .square-icon{width:10px;height:10px;background:#0284c7;border-radius:2px}.btn-tool .circle-icon{width:10px;height:10px;background:#000;border-radius:50%}.btn-tool.btn-add-cohort{background:#e0f2fe;color:#0369a1;border-color:#bae6fd}.btn-tool.btn-add-cohort:hover{background:#bae6fd;color:#0284c7}.btn-tool.btn-add-dep{background:#f1f5f9;color:#1e293b;border-color:#cbd5e1}.btn-tool.btn-add-dep:hover{background:#e2e8f0;color:#000;border-color:#94a3b8}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'lib-toolbar', standalone: true, imports: [CommonModule], template: "<div class=\"toolbar-container\" *ngIf=\"!readonly\">\n  <button \n    type=\"button\" \n    class=\"btn-tool btn-add-dep\" \n    (click)=\"addDependency.emit()\"\n    title=\"Add a Dependency / Delay component\"\n  >\n    <span class=\"tool-icon circle-icon\"></span>\n    <span>+ Add Dependency</span>\n  </button>\n</div>\n", styles: [":host{display:block}.toolbar-container{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 2px 6px #0000000d;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;position:absolute;top:14px;left:14px;z-index:20}.btn-tool{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .15s ease}.btn-tool .tool-icon{display:inline-block}.btn-tool .square-icon{width:10px;height:10px;background:#0284c7;border-radius:2px}.btn-tool .circle-icon{width:10px;height:10px;background:#000;border-radius:50%}.btn-tool.btn-add-cohort{background:#e0f2fe;color:#0369a1;border-color:#bae6fd}.btn-tool.btn-add-cohort:hover{background:#bae6fd;color:#0284c7}.btn-tool.btn-add-dep{background:#f1f5f9;color:#1e293b;border-color:#cbd5e1}.btn-tool.btn-add-dep:hover{background:#e2e8f0;color:#000;border-color:#94a3b8}\n"] }]
        }], propDecorators: { readonly: [{
                type: Input
            }], addCohort: [{
                type: Output
            }], addDependency: [{
                type: Output
            }] } });

class CohortDesignerComponent {
    service = inject(CohortDesignerService);
    flowData;
    readonly = false;
    customIcons = [];
    flowChange = new EventEmitter();
    save = new EventEmitter();
    nodeSelected = new EventEmitter();
    connectionSelected = new EventEmitter();
    canvasContainer;
    nodes = this.service.nodes;
    connections = this.service.connections;
    selectedNode = this.service.selectedNode;
    selectedConnection = this.service.selectedConnection;
    activeConnecting = this.service.activeConnecting;
    transform = this.service.transform;
    // Node Dragging State
    isDraggingNode = false;
    draggedNodeId = null;
    dragNodeOffset = { x: 0, y: 0 };
    // Node Resizing State (Dragging sides to resize)
    isResizing = false;
    resizeState = null;
    // Canvas Panning State
    isPanningCanvas = false;
    panStart = { x: 0, y: 0 };
    panInitial = { x: 0, y: 0 };
    ngOnInit() {
        if (this.flowData && this.flowData.nodes) {
            this.service.loadFlow(this.flowData);
        }
    }
    ngOnChanges(changes) {
        if (changes['flowData'] && !changes['flowData'].isFirstChange() && this.flowData) {
            this.service.loadFlow(this.flowData);
        }
    }
    // --- Public Pluggable Component API ---
    getData() {
        return this.service.getData();
    }
    saveData() {
        const data = this.service.save();
        this.save.emit(data);
        return data;
    }
    loadData(flow) {
        this.service.loadFlow(flow);
        this.flowChange.emit(this.service.getData());
    }
    clear() {
        this.service.clearAll();
        this.flowChange.emit(this.service.getData());
    }
    addCohort(nameOrX, subjectsOrY, data) {
        const c = this.service.addCohort(nameOrX, subjectsOrY, data);
        this.flowChange.emit(this.service.getData());
        return c;
    }
    addCohortByName(name, data) {
        const c = this.service.addCohortByName(name, data);
        this.flowChange.emit(this.service.getData());
        return c;
    }
    addCohorts(items) {
        const res = this.service.addCohorts(items);
        this.flowChange.emit(this.service.getData());
        return res;
    }
    addDependency(x, y, customDataOrIcon) {
        const d = this.service.addDependency(x, y, customDataOrIcon);
        this.flowChange.emit(this.service.getData());
        return d;
    }
    // --- Coordinate Mapping ---
    getCanvasCoordinates(clientX, clientY) {
        const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
        const { panX, panY, zoom } = this.transform();
        const x = (clientX - rect.left - panX) / zoom;
        const y = (clientY - rect.top - panY) / zoom;
        return { x, y };
    }
    // --- SVG Connection paths ---
    getConnectionPath(conn) {
        const fromCoords = this.service.getPortCoordinates(conn.fromNodeId, conn.fromPort);
        const toCoords = this.service.getPortCoordinates(conn.toNodeId, conn.toPort);
        return this.service.calculateBezierPath(fromCoords.x, fromCoords.y, conn.fromPort, toCoords.x, toCoords.y, conn.toPort);
    }
    getConnectionMidpoint(conn) {
        const fromCoords = this.service.getPortCoordinates(conn.fromNodeId, conn.fromPort);
        const toCoords = this.service.getPortCoordinates(conn.toNodeId, conn.toPort);
        return {
            x: (fromCoords.x + toCoords.x) / 2,
            y: (fromCoords.y + toCoords.y) / 2
        };
    }
    getActiveConnectingPath() {
        const active = this.activeConnecting();
        if (!active)
            return '';
        return this.service.calculateBezierPath(active.startX, active.startY, active.fromPort, active.currentX, active.currentY, active.fromPort === 'right' ? 'left' : 'right');
    }
    // --- Node Dragging & Resizing ---
    onCohortResizeStart(data) {
        if (this.readonly || data.event.button !== 0)
            return;
        const node = this.nodes().find(n => n.id === data.nodeId);
        if (!node)
            return;
        this.isResizing = true;
        this.resizeState = {
            nodeId: data.nodeId,
            side: data.side,
            startClientX: data.event.clientX,
            startClientY: data.event.clientY,
            initialWidth: node.width || (node.isExpanded ? 280 : 180),
            initialHeight: node.height || (node.isExpanded ? 54 : 50),
            initialX: node.x,
            initialY: node.y
        };
        this.service.selectNode(node.id);
        this.nodeSelected.emit(node);
    }
    onNodeMouseDown(node, event) {
        if (this.readonly || event.button !== 0)
            return;
        const target = event.target;
        if (target.closest('.port-handle') ||
            target.closest('.resize-handle') ||
            target.closest('button') ||
            target.closest('input')) {
            return;
        }
        this.isDraggingNode = true;
        this.draggedNodeId = node.id;
        this.service.selectNode(node.id);
        this.nodeSelected.emit(node);
        const canvasCoords = this.getCanvasCoordinates(event.clientX, event.clientY);
        this.dragNodeOffset = {
            x: canvasCoords.x - node.x,
            y: canvasCoords.y - node.y
        };
        event.preventDefault();
    }
    // --- Canvas Interaction ---
    onCanvasMouseDown(event) {
        const target = event.target;
        const isBackground = target === this.canvasContainer.nativeElement ||
            target.classList.contains('canvas-grid') ||
            target.tagName.toLowerCase() === 'svg';
        if (isBackground) {
            // If user clicks on canvas while drawing an arrow, cancel and reset immediately
            if (this.activeConnecting()) {
                this.service.cancelConnection();
                return;
            }
            this.service.clearSelection();
            this.nodeSelected.emit(null);
            this.connectionSelected.emit(null);
            // Pan canvas
            if (event.button === 0 || event.button === 1) {
                this.isPanningCanvas = true;
                this.panStart = { x: event.clientX, y: event.clientY };
                const currentTransform = this.transform();
                this.panInitial = { x: currentTransform.panX, y: currentTransform.panY };
                event.preventDefault();
            }
        }
    }
    onWindowMouseMove(event) {
        if (this.resizeState) {
            const { zoom } = this.transform();
            const deltaX = (event.clientX - this.resizeState.startClientX) / zoom;
            const deltaY = (event.clientY - this.resizeState.startClientY) / zoom;
            const MIN_WIDTH = 140;
            const MAX_WIDTH = 700;
            const MIN_HEIGHT = 44;
            const MAX_HEIGHT = 260;
            let newWidth = this.resizeState.initialWidth;
            let newHeight = this.resizeState.initialHeight;
            let newX = this.resizeState.initialX;
            let newY = this.resizeState.initialY;
            if (this.resizeState.side === 'right' || this.resizeState.side === 'corner') {
                newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, Math.round(this.resizeState.initialWidth + deltaX)));
            }
            else if (this.resizeState.side === 'left') {
                const rawWidth = Math.round(this.resizeState.initialWidth - deltaX);
                newWidth = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, rawWidth));
                newX = Math.round(this.resizeState.initialX + (this.resizeState.initialWidth - newWidth));
            }
            if (this.resizeState.side === 'bottom' || this.resizeState.side === 'corner') {
                newHeight = Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, Math.round(this.resizeState.initialHeight + deltaY)));
            }
            this.service.updateNodeDimensions(this.resizeState.nodeId, newWidth, newHeight, newX, newY);
            return;
        }
        if (this.isDraggingNode && this.draggedNodeId) {
            const canvasCoords = this.getCanvasCoordinates(event.clientX, event.clientY);
            const newX = Math.round(canvasCoords.x - this.dragNodeOffset.x);
            const newY = Math.round(canvasCoords.y - this.dragNodeOffset.y);
            this.service.updateNodePosition(this.draggedNodeId, newX, newY);
            return;
        }
        if (this.activeConnecting()) {
            const canvasCoords = this.getCanvasCoordinates(event.clientX, event.clientY);
            this.service.updateConnectingPosition(canvasCoords.x, canvasCoords.y);
            return;
        }
        if (this.isPanningCanvas) {
            const deltaX = event.clientX - this.panStart.x;
            const deltaY = event.clientY - this.panStart.y;
            const current = this.transform();
            this.service.setTransform(current.zoom, this.panInitial.x + deltaX, this.panInitial.y + deltaY);
        }
    }
    onWindowMouseUp(event) {
        if (this.resizeState) {
            this.isResizing = false;
            this.resizeState = null;
            this.flowChange.emit(this.service.getData());
        }
        if (this.isDraggingNode) {
            this.isDraggingNode = false;
            this.draggedNodeId = null;
            this.flowChange.emit(this.service.getData());
        }
        if (this.isPanningCanvas) {
            this.isPanningCanvas = false;
        }
        // If user was drawing a wire and released mouse outside a port: RESET AND CANCEL ARROW
        if (this.activeConnecting()) {
            const targetElem = document.elementFromPoint(event.clientX, event.clientY);
            const portEl = targetElem?.closest('.port-handle');
            if (!portEl) {
                // Left the arrow without dropping on a valid port -> reset back immediately!
                this.service.cancelConnection();
            }
        }
    }
    onCanvasWheel(event) {
        if (this.canvasContainer.nativeElement.contains(event.target)) {
            event.preventDefault();
            const zoomFactor = event.deltaY < 0 ? 0.08 : -0.08;
            this.service.zoomBy(zoomFactor);
        }
    }
    onKeyDown(event) {
        if (this.readonly)
            return;
        if (event.key === 'Delete' || event.key === 'Backspace') {
            const activeEl = document.activeElement;
            if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT')) {
                return;
            }
            if (this.service.selectedNodeId()) {
                this.service.deleteNode(this.service.selectedNodeId());
                this.flowChange.emit(this.service.getData());
            }
            else if (this.service.selectedConnectionId()) {
                this.service.deleteConnection(this.service.selectedConnectionId());
                this.flowChange.emit(this.service.getData());
            }
        }
        if (event.key === 'Escape') {
            if (this.activeConnecting()) {
                this.service.cancelConnection();
            }
            else {
                this.service.clearSelection();
            }
        }
    }
    // --- Port Connection Handlers (Left & Right) ---
    onPortClick(data) {
        if (this.readonly)
            return;
        const active = this.activeConnecting();
        if (!active) {
            const canvasCoords = this.getCanvasCoordinates(data.event.clientX, data.event.clientY);
            this.service.startConnection(data.nodeId, data.port, canvasCoords.x, canvasCoords.y);
        }
        else {
            const completed = this.service.completeConnection(data.nodeId, data.port);
            if (completed) {
                this.flowChange.emit(this.service.getData());
            }
        }
    }
    onPortMouseUp(data) {
        if (this.readonly)
            return;
        const active = this.activeConnecting();
        if (active && active.fromNodeId !== data.nodeId) {
            const completed = this.service.completeConnection(data.nodeId, data.port);
            if (completed) {
                this.flowChange.emit(this.service.getData());
            }
        }
    }
    onSelectNode(nodeId) {
        this.service.selectNode(nodeId);
        this.nodeSelected.emit(this.service.selectedNode());
    }
    onSelectConnection(connId, event) {
        event.stopPropagation();
        this.service.selectConnection(connId);
        this.connectionSelected.emit(this.service.selectedConnection());
    }
    onCloseInspector() {
        this.service.isRightPanelOpen.set(false);
        this.service.clearSelection();
        this.nodeSelected.emit(null);
        this.connectionSelected.emit(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortDesignerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: CohortDesignerComponent, isStandalone: true, selector: "ngx-cohort-designer", inputs: { flowData: "flowData", readonly: "readonly", customIcons: "customIcons" }, outputs: { flowChange: "flowChange", save: "save", nodeSelected: "nodeSelected", connectionSelected: "connectionSelected" }, host: { listeners: { "window:mousemove": "onWindowMouseMove($event)", "window:mouseup": "onWindowMouseUp($event)", "wheel": "onCanvasWheel($event)", "window:keydown": "onKeyDown($event)" } }, viewQueries: [{ propertyName: "canvasContainer", first: true, predicate: ["canvasContainer"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"cohort-designer-root\">\n  <!-- Minimal Add Toolbar (Add Cohort & Add Dependency only) -->\n  <lib-toolbar\n    [readonly]=\"readonly\"\n    (addCohort)=\"addCohort()\"\n    (addDependency)=\"addDependency()\"\n  ></lib-toolbar>\n\n  <!-- Right Panel Toggle Button (Overview of all cohorts & dependencies) -->\n  <div class=\"overview-toggle-wrapper\">\n    <button \n      type=\"button\" \n      class=\"btn-toggle-overview\" \n      [class.active]=\"service.isRightPanelOpen()\"\n      (click)=\"service.toggleRightPanel()\"\n      title=\"View all cohorts and dependencies together\"\n    >\n      <svg viewBox=\"0 0 24 24\" width=\"13\" height=\"13\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n        <line x1=\"8\" y1=\"6\" x2=\"21\" y2=\"6\"></line>\n        <line x1=\"8\" y1=\"12\" x2=\"21\" y2=\"12\"></line>\n        <line x1=\"8\" y1=\"18\" x2=\"21\" y2=\"18\"></line>\n        <line x1=\"3\" y1=\"6\" x2=\"3.01\" y2=\"6\"></line>\n        <line x1=\"3\" y1=\"12\" x2=\"3.01\" y2=\"12\"></line>\n        <line x1=\"3\" y1=\"18\" x2=\"3.01\" y2=\"18\"></line>\n      </svg>\n      <span>All Blocks ({{ nodes().length }})</span>\n    </button>\n  </div>\n\n  <!-- Canvas Workspace -->\n  <div class=\"designer-workspace\">\n    <!-- Interactive Canvas Viewport -->\n    <div \n      #canvasContainer \n      class=\"canvas-container\"\n      [class.connecting-mode]=\"!!activeConnecting()\"\n      [class.panning-mode]=\"isPanningCanvas\"\n      [class.resizing-mode]=\"isResizing\"\n      (mousedown)=\"onCanvasMouseDown($event)\"\n    >\n      <!-- Background Grid -->\n      <div \n        class=\"canvas-grid\" \n        [style.transform]=\"'translate(' + transform().panX + 'px, ' + transform().panY + 'px) scale(' + transform().zoom + ')'\"\n      >\n        <!-- SVG Connections Layer -->\n        <svg class=\"connections-svg\">\n          <defs>\n            <marker\n              id=\"arrow-default\"\n              viewBox=\"0 0 10 10\"\n              refX=\"8\"\n              refY=\"5\"\n              markerWidth=\"6\"\n              markerHeight=\"6\"\n              orient=\"auto-start-reverse\"\n            >\n              <path d=\"M 0 1.5 L 8 5 L 0 8.5 z\" fill=\"#0284c7\" />\n            </marker>\n\n            <marker\n              id=\"arrow-selected\"\n              viewBox=\"0 0 10 10\"\n              refX=\"8\"\n              refY=\"5\"\n              markerWidth=\"7\"\n              markerHeight=\"7\"\n              orient=\"auto-start-reverse\"\n            >\n              <path d=\"M 0 1.5 L 8 5 L 0 8.5 z\" fill=\"#0f172a\" />\n            </marker>\n          </defs>\n\n          <!-- Established Connections -->\n          <g class=\"connections-group\">\n            <ng-container *ngFor=\"let conn of connections()\">\n              <!-- Invisible hit area for easier clicking -->\n              <path\n                class=\"wire-hit-area\"\n                [attr.d]=\"getConnectionPath(conn)\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              />\n\n              <!-- Visible connection line -->\n              <path\n                class=\"wire-path\"\n                [class.selected]=\"selectedConnection()?.id === conn.id\"\n                [attr.d]=\"getConnectionPath(conn)\"\n                [style.stroke]=\"conn.color || '#0284c7'\"\n                [attr.marker-end]=\"selectedConnection()?.id === conn.id ? 'url(#arrow-selected)' : 'url(#arrow-default)'\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              />\n\n              <!-- Optional Wire Label -->\n              <g \n                *ngIf=\"conn.label\" \n                class=\"wire-label-group\"\n                [attr.transform]=\"'translate(' + getConnectionMidpoint(conn).x + ', ' + getConnectionMidpoint(conn).y + ')'\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              >\n                <rect \n                  x=\"-25\" \n                  y=\"-9\" \n                  width=\"50\" \n                  height=\"18\" \n                  rx=\"3\" \n                  class=\"wire-label-bg\"\n                />\n                <text \n                  x=\"0\" \n                  y=\"3\" \n                  text-anchor=\"middle\" \n                  class=\"wire-label-text\"\n                >\n                  {{ conn.label }}\n                </text>\n              </g>\n            </ng-container>\n\n            <!-- Dynamic Active Cable following mouse pointer -->\n            <path\n              *ngIf=\"activeConnecting()\"\n              class=\"active-wire-drawing\"\n              [attr.d]=\"getActiveConnectingPath()\"\n              marker-end=\"url(#arrow-default)\"\n            />\n          </g>\n        </svg>\n\n        <!-- Nodes HTML Layer -->\n        <div class=\"nodes-layer\">\n          <ng-container *ngFor=\"let node of nodes()\">\n            <!-- Cohort Block (Square / Card) -->\n            <div\n              *ngIf=\"node.type === 'cohort'\"\n              class=\"node-wrapper\"\n              [style.transform]=\"'translate(' + node.x + 'px, ' + node.y + 'px)'\"\n              (mousedown)=\"onNodeMouseDown(node, $event)\"\n            >\n              <lib-cohort-node\n                [node]=\"$any(node)\"\n                [isSelected]=\"selectedNode()?.id === node.id\"\n                [readonly]=\"readonly\"\n                (selectNode)=\"onSelectNode($event)\"\n                (portClick)=\"onPortClick($event)\"\n                (portMouseUp)=\"onPortMouseUp($event)\"\n                (deleteNode)=\"service.deleteNode($event)\"\n                (resizeStart)=\"onCohortResizeStart($event)\"\n              ></lib-cohort-node>\n            </div>\n\n            <!-- Dependency Block (Circle / Icon) -->\n            <div\n              *ngIf=\"node.type === 'dependency'\"\n              class=\"node-wrapper\"\n              [style.transform]=\"'translate(' + node.x + 'px, ' + node.y + 'px)'\"\n              (mousedown)=\"onNodeMouseDown(node, $event)\"\n            >\n              <lib-dependency-node\n                [node]=\"$any(node)\"\n                [isSelected]=\"selectedNode()?.id === node.id\"\n                [readonly]=\"readonly\"\n                [customIcons]=\"customIcons\"\n                (selectNode)=\"onSelectNode($event)\"\n                (portClick)=\"onPortClick($event)\"\n                (portMouseUp)=\"onPortMouseUp($event)\"\n                (deleteNode)=\"service.deleteNode($event)\"\n              ></lib-dependency-node>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n\n      <!-- Connecting Guide Banner -->\n      <div class=\"connecting-banner\" *ngIf=\"activeConnecting()\">\n        <span class=\"banner-pulse\"></span>\n        <span>Drag or click to target port (Left/Right) to connect, or release/press <strong>Esc</strong> to cancel.</span>\n      </div>\n    </div>\n\n    <!-- Right Side Panel: Overview of All Blocks or Edit Selected -->\n    <div \n      class=\"inspector-container\" \n      [class.open]=\"service.isRightPanelOpen()\"\n      [class.wide-panel]=\"service.rightPanelTab() === 'overview'\"\n    >\n      <lib-inspector-panel\n        *ngIf=\"service.isRightPanelOpen()\"\n        [node]=\"selectedNode()\"\n        [connection]=\"selectedConnection()\"\n        [customIcons]=\"customIcons\"\n        [readonly]=\"readonly\"\n        (close)=\"onCloseInspector()\"\n      ></lib-inspector-panel>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%;height:100%;overflow:hidden;box-sizing:border-box}.cohort-designer-root{display:flex;flex-direction:column;width:100%;height:100%;position:relative;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}.overview-toggle-wrapper{position:absolute;top:14px;right:14px;z-index:25}.overview-toggle-wrapper .btn-toggle-overview{display:inline-flex;align-items:center;gap:6px;padding:7px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;font-size:12px;font-weight:600;color:#475569;box-shadow:0 2px 6px #0000000d;cursor:pointer;transition:all .15s ease}.overview-toggle-wrapper .btn-toggle-overview:hover{background:#f1f5f9;color:#0f172a;border-color:#cbd5e1}.overview-toggle-wrapper .btn-toggle-overview.active{background:#0284c7;color:#fff;border-color:#0284c7}.designer-workspace{display:flex;flex:1;position:relative;overflow:hidden}.canvas-container{flex:1;height:100%;position:relative;overflow:hidden;background-color:#f8fafc;background-image:radial-gradient(#cbd5e1 1.2px,transparent 1.2px),radial-gradient(#e2e8f0 1.2px,#f8fafc 1.2px);background-size:24px 24px;background-position:0 0,12px 12px;cursor:default}.canvas-container.connecting-mode{cursor:crosshair}.canvas-container.panning-mode{cursor:grab}.canvas-container.panning-mode:active{cursor:grabbing}.canvas-container.resizing-mode{cursor:ew-resize}.canvas-grid{position:absolute;top:0;left:0;width:10000px;height:10000px;transform-origin:0 0;will-change:transform}.connections-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;overflow:visible}.connections-svg .connections-group{pointer-events:auto}.wire-hit-area{fill:none;stroke:transparent;stroke-width:18px;cursor:pointer;pointer-events:stroke}.wire-path{fill:none;stroke-width:2px;cursor:pointer;pointer-events:stroke;transition:stroke .15s ease,stroke-width .15s ease}.wire-path:hover{stroke-width:3.5px;stroke:#0284c7!important}.wire-path.selected{stroke-width:3.5px;stroke:#0f172a!important;filter:drop-shadow(0 0 3px rgba(15,23,42,.4))}.active-wire-drawing{fill:none;stroke:#0284c7;stroke-width:2px;stroke-dasharray:5,4;animation:dash-draw .8s linear infinite;pointer-events:none}@keyframes dash-draw{0%{stroke-dashoffset:18}to{stroke-dashoffset:0}}.wire-label-group{cursor:pointer;pointer-events:auto}.wire-label-group .wire-label-bg{fill:#fff;stroke:#cbd5e1;stroke-width:1px;filter:drop-shadow(0 1px 2px rgba(0,0,0,.08))}.wire-label-group .wire-label-text{font-size:9px;font-weight:600;fill:#475569;-webkit-user-select:none;user-select:none}.nodes-layer{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:2}.node-wrapper{position:absolute;top:0;left:0;pointer-events:auto;will-change:transform;cursor:move}.connecting-banner{position:absolute;bottom:16px;left:50%;transform:translate(-50%);background:#0f172a;color:#f8fafc;padding:8px 16px;border-radius:20px;font-size:12px;display:flex;align-items:center;gap:8px;box-shadow:0 4px 12px #00000026;z-index:20;pointer-events:none}.connecting-banner .banner-pulse{width:7px;height:7px;background:#38bdf8;border-radius:50%}.inspector-container{width:0;height:100%;position:relative;z-index:30;transition:width .25s cubic-bezier(.16,1,.3,1);overflow:hidden;box-shadow:-4px 0 16px #00000014}.inspector-container.open{width:350px}.inspector-container.open.wide-panel{width:min(580px,50vw);min-width:440px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CohortNodeComponent, selector: "lib-cohort-node", inputs: ["node", "isSelected", "readonly"], outputs: ["selectNode", "portClick", "portMouseUp", "deleteNode", "resizeStart"] }, { kind: "component", type: DependencyNodeComponent, selector: "lib-dependency-node", inputs: ["node", "isSelected", "readonly", "customIcons"], outputs: ["selectNode", "portClick", "portMouseUp", "deleteNode"] }, { kind: "component", type: InspectorPanelComponent, selector: "lib-inspector-panel", inputs: ["node", "connection", "customIcons", "readonly"], outputs: ["close"] }, { kind: "component", type: ToolbarComponent, selector: "lib-toolbar", inputs: ["readonly"], outputs: ["addCohort", "addDependency"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: CohortDesignerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-cohort-designer', standalone: true, imports: [
                        CommonModule,
                        CohortNodeComponent,
                        DependencyNodeComponent,
                        InspectorPanelComponent,
                        ToolbarComponent
                    ], template: "<div class=\"cohort-designer-root\">\n  <!-- Minimal Add Toolbar (Add Cohort & Add Dependency only) -->\n  <lib-toolbar\n    [readonly]=\"readonly\"\n    (addCohort)=\"addCohort()\"\n    (addDependency)=\"addDependency()\"\n  ></lib-toolbar>\n\n  <!-- Right Panel Toggle Button (Overview of all cohorts & dependencies) -->\n  <div class=\"overview-toggle-wrapper\">\n    <button \n      type=\"button\" \n      class=\"btn-toggle-overview\" \n      [class.active]=\"service.isRightPanelOpen()\"\n      (click)=\"service.toggleRightPanel()\"\n      title=\"View all cohorts and dependencies together\"\n    >\n      <svg viewBox=\"0 0 24 24\" width=\"13\" height=\"13\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\">\n        <line x1=\"8\" y1=\"6\" x2=\"21\" y2=\"6\"></line>\n        <line x1=\"8\" y1=\"12\" x2=\"21\" y2=\"12\"></line>\n        <line x1=\"8\" y1=\"18\" x2=\"21\" y2=\"18\"></line>\n        <line x1=\"3\" y1=\"6\" x2=\"3.01\" y2=\"6\"></line>\n        <line x1=\"3\" y1=\"12\" x2=\"3.01\" y2=\"12\"></line>\n        <line x1=\"3\" y1=\"18\" x2=\"3.01\" y2=\"18\"></line>\n      </svg>\n      <span>All Blocks ({{ nodes().length }})</span>\n    </button>\n  </div>\n\n  <!-- Canvas Workspace -->\n  <div class=\"designer-workspace\">\n    <!-- Interactive Canvas Viewport -->\n    <div \n      #canvasContainer \n      class=\"canvas-container\"\n      [class.connecting-mode]=\"!!activeConnecting()\"\n      [class.panning-mode]=\"isPanningCanvas\"\n      [class.resizing-mode]=\"isResizing\"\n      (mousedown)=\"onCanvasMouseDown($event)\"\n    >\n      <!-- Background Grid -->\n      <div \n        class=\"canvas-grid\" \n        [style.transform]=\"'translate(' + transform().panX + 'px, ' + transform().panY + 'px) scale(' + transform().zoom + ')'\"\n      >\n        <!-- SVG Connections Layer -->\n        <svg class=\"connections-svg\">\n          <defs>\n            <marker\n              id=\"arrow-default\"\n              viewBox=\"0 0 10 10\"\n              refX=\"8\"\n              refY=\"5\"\n              markerWidth=\"6\"\n              markerHeight=\"6\"\n              orient=\"auto-start-reverse\"\n            >\n              <path d=\"M 0 1.5 L 8 5 L 0 8.5 z\" fill=\"#0284c7\" />\n            </marker>\n\n            <marker\n              id=\"arrow-selected\"\n              viewBox=\"0 0 10 10\"\n              refX=\"8\"\n              refY=\"5\"\n              markerWidth=\"7\"\n              markerHeight=\"7\"\n              orient=\"auto-start-reverse\"\n            >\n              <path d=\"M 0 1.5 L 8 5 L 0 8.5 z\" fill=\"#0f172a\" />\n            </marker>\n          </defs>\n\n          <!-- Established Connections -->\n          <g class=\"connections-group\">\n            <ng-container *ngFor=\"let conn of connections()\">\n              <!-- Invisible hit area for easier clicking -->\n              <path\n                class=\"wire-hit-area\"\n                [attr.d]=\"getConnectionPath(conn)\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              />\n\n              <!-- Visible connection line -->\n              <path\n                class=\"wire-path\"\n                [class.selected]=\"selectedConnection()?.id === conn.id\"\n                [attr.d]=\"getConnectionPath(conn)\"\n                [style.stroke]=\"conn.color || '#0284c7'\"\n                [attr.marker-end]=\"selectedConnection()?.id === conn.id ? 'url(#arrow-selected)' : 'url(#arrow-default)'\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              />\n\n              <!-- Optional Wire Label -->\n              <g \n                *ngIf=\"conn.label\" \n                class=\"wire-label-group\"\n                [attr.transform]=\"'translate(' + getConnectionMidpoint(conn).x + ', ' + getConnectionMidpoint(conn).y + ')'\"\n                (click)=\"onSelectConnection(conn.id, $event)\"\n              >\n                <rect \n                  x=\"-25\" \n                  y=\"-9\" \n                  width=\"50\" \n                  height=\"18\" \n                  rx=\"3\" \n                  class=\"wire-label-bg\"\n                />\n                <text \n                  x=\"0\" \n                  y=\"3\" \n                  text-anchor=\"middle\" \n                  class=\"wire-label-text\"\n                >\n                  {{ conn.label }}\n                </text>\n              </g>\n            </ng-container>\n\n            <!-- Dynamic Active Cable following mouse pointer -->\n            <path\n              *ngIf=\"activeConnecting()\"\n              class=\"active-wire-drawing\"\n              [attr.d]=\"getActiveConnectingPath()\"\n              marker-end=\"url(#arrow-default)\"\n            />\n          </g>\n        </svg>\n\n        <!-- Nodes HTML Layer -->\n        <div class=\"nodes-layer\">\n          <ng-container *ngFor=\"let node of nodes()\">\n            <!-- Cohort Block (Square / Card) -->\n            <div\n              *ngIf=\"node.type === 'cohort'\"\n              class=\"node-wrapper\"\n              [style.transform]=\"'translate(' + node.x + 'px, ' + node.y + 'px)'\"\n              (mousedown)=\"onNodeMouseDown(node, $event)\"\n            >\n              <lib-cohort-node\n                [node]=\"$any(node)\"\n                [isSelected]=\"selectedNode()?.id === node.id\"\n                [readonly]=\"readonly\"\n                (selectNode)=\"onSelectNode($event)\"\n                (portClick)=\"onPortClick($event)\"\n                (portMouseUp)=\"onPortMouseUp($event)\"\n                (deleteNode)=\"service.deleteNode($event)\"\n                (resizeStart)=\"onCohortResizeStart($event)\"\n              ></lib-cohort-node>\n            </div>\n\n            <!-- Dependency Block (Circle / Icon) -->\n            <div\n              *ngIf=\"node.type === 'dependency'\"\n              class=\"node-wrapper\"\n              [style.transform]=\"'translate(' + node.x + 'px, ' + node.y + 'px)'\"\n              (mousedown)=\"onNodeMouseDown(node, $event)\"\n            >\n              <lib-dependency-node\n                [node]=\"$any(node)\"\n                [isSelected]=\"selectedNode()?.id === node.id\"\n                [readonly]=\"readonly\"\n                [customIcons]=\"customIcons\"\n                (selectNode)=\"onSelectNode($event)\"\n                (portClick)=\"onPortClick($event)\"\n                (portMouseUp)=\"onPortMouseUp($event)\"\n                (deleteNode)=\"service.deleteNode($event)\"\n              ></lib-dependency-node>\n            </div>\n          </ng-container>\n        </div>\n      </div>\n\n      <!-- Connecting Guide Banner -->\n      <div class=\"connecting-banner\" *ngIf=\"activeConnecting()\">\n        <span class=\"banner-pulse\"></span>\n        <span>Drag or click to target port (Left/Right) to connect, or release/press <strong>Esc</strong> to cancel.</span>\n      </div>\n    </div>\n\n    <!-- Right Side Panel: Overview of All Blocks or Edit Selected -->\n    <div \n      class=\"inspector-container\" \n      [class.open]=\"service.isRightPanelOpen()\"\n      [class.wide-panel]=\"service.rightPanelTab() === 'overview'\"\n    >\n      <lib-inspector-panel\n        *ngIf=\"service.isRightPanelOpen()\"\n        [node]=\"selectedNode()\"\n        [connection]=\"selectedConnection()\"\n        [customIcons]=\"customIcons\"\n        [readonly]=\"readonly\"\n        (close)=\"onCloseInspector()\"\n      ></lib-inspector-panel>\n    </div>\n  </div>\n</div>\n", styles: [":host{display:block;width:100%;height:100%;overflow:hidden;box-sizing:border-box}.cohort-designer-root{display:flex;flex-direction:column;width:100%;height:100%;position:relative;background:#f8fafc;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif}.overview-toggle-wrapper{position:absolute;top:14px;right:14px;z-index:25}.overview-toggle-wrapper .btn-toggle-overview{display:inline-flex;align-items:center;gap:6px;padding:7px 12px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;font-size:12px;font-weight:600;color:#475569;box-shadow:0 2px 6px #0000000d;cursor:pointer;transition:all .15s ease}.overview-toggle-wrapper .btn-toggle-overview:hover{background:#f1f5f9;color:#0f172a;border-color:#cbd5e1}.overview-toggle-wrapper .btn-toggle-overview.active{background:#0284c7;color:#fff;border-color:#0284c7}.designer-workspace{display:flex;flex:1;position:relative;overflow:hidden}.canvas-container{flex:1;height:100%;position:relative;overflow:hidden;background-color:#f8fafc;background-image:radial-gradient(#cbd5e1 1.2px,transparent 1.2px),radial-gradient(#e2e8f0 1.2px,#f8fafc 1.2px);background-size:24px 24px;background-position:0 0,12px 12px;cursor:default}.canvas-container.connecting-mode{cursor:crosshair}.canvas-container.panning-mode{cursor:grab}.canvas-container.panning-mode:active{cursor:grabbing}.canvas-container.resizing-mode{cursor:ew-resize}.canvas-grid{position:absolute;top:0;left:0;width:10000px;height:10000px;transform-origin:0 0;will-change:transform}.connections-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:1;overflow:visible}.connections-svg .connections-group{pointer-events:auto}.wire-hit-area{fill:none;stroke:transparent;stroke-width:18px;cursor:pointer;pointer-events:stroke}.wire-path{fill:none;stroke-width:2px;cursor:pointer;pointer-events:stroke;transition:stroke .15s ease,stroke-width .15s ease}.wire-path:hover{stroke-width:3.5px;stroke:#0284c7!important}.wire-path.selected{stroke-width:3.5px;stroke:#0f172a!important;filter:drop-shadow(0 0 3px rgba(15,23,42,.4))}.active-wire-drawing{fill:none;stroke:#0284c7;stroke-width:2px;stroke-dasharray:5,4;animation:dash-draw .8s linear infinite;pointer-events:none}@keyframes dash-draw{0%{stroke-dashoffset:18}to{stroke-dashoffset:0}}.wire-label-group{cursor:pointer;pointer-events:auto}.wire-label-group .wire-label-bg{fill:#fff;stroke:#cbd5e1;stroke-width:1px;filter:drop-shadow(0 1px 2px rgba(0,0,0,.08))}.wire-label-group .wire-label-text{font-size:9px;font-weight:600;fill:#475569;-webkit-user-select:none;user-select:none}.nodes-layer{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:2}.node-wrapper{position:absolute;top:0;left:0;pointer-events:auto;will-change:transform;cursor:move}.connecting-banner{position:absolute;bottom:16px;left:50%;transform:translate(-50%);background:#0f172a;color:#f8fafc;padding:8px 16px;border-radius:20px;font-size:12px;display:flex;align-items:center;gap:8px;box-shadow:0 4px 12px #00000026;z-index:20;pointer-events:none}.connecting-banner .banner-pulse{width:7px;height:7px;background:#38bdf8;border-radius:50%}.inspector-container{width:0;height:100%;position:relative;z-index:30;transition:width .25s cubic-bezier(.16,1,.3,1);overflow:hidden;box-shadow:-4px 0 16px #00000014}.inspector-container.open{width:350px}.inspector-container.open.wide-panel{width:min(580px,50vw);min-width:440px}\n"] }]
        }], propDecorators: { flowData: [{
                type: Input
            }], readonly: [{
                type: Input
            }], customIcons: [{
                type: Input
            }], flowChange: [{
                type: Output
            }], save: [{
                type: Output
            }], nodeSelected: [{
                type: Output
            }], connectionSelected: [{
                type: Output
            }], canvasContainer: [{
                type: ViewChild,
                args: ['canvasContainer', { static: true }]
            }], onWindowMouseMove: [{
                type: HostListener,
                args: ['window:mousemove', ['$event']]
            }], onWindowMouseUp: [{
                type: HostListener,
                args: ['window:mouseup', ['$event']]
            }], onCanvasWheel: [{
                type: HostListener,
                args: ['wheel', ['$event']]
            }], onKeyDown: [{
                type: HostListener,
                args: ['window:keydown', ['$event']]
            }] } });

const PROTOCOL_TEMPLATES = [
    {
        id: 'sequential_cohorts',
        name: 'Sequential Cohort Design',
        description: 'Sequential dose escalation cohorts with inter-cohort safety delay.',
        flow: {
            version: '1.0.0',
            nodes: [
                {
                    id: 'coh-1',
                    type: 'cohort',
                    x: 60,
                    y: 180,
                    name: 'Cohort A',
                    subjects: 6,
                    color: '#0284c7',
                    description: 'Initial starting dose cohort.'
                },
                {
                    id: 'dep-1',
                    type: 'dependency',
                    x: 280,
                    y: 184,
                    name: 'Safety Delay',
                    days: 14,
                    icon: 'clock',
                    color: '#000000'
                },
                {
                    id: 'coh-2',
                    type: 'cohort',
                    x: 420,
                    y: 180,
                    name: 'Cohort B',
                    subjects: 12,
                    color: '#4f46e5',
                    description: 'Dose escalation level 2.'
                },
                {
                    id: 'dep-2',
                    type: 'dependency',
                    x: 640,
                    y: 184,
                    name: 'Follow-up Delay',
                    days: 28,
                    icon: 'clock',
                    color: '#000000'
                },
                {
                    id: 'coh-3',
                    type: 'cohort',
                    x: 780,
                    y: 180,
                    name: 'Expansion Cohort',
                    subjects: 30,
                    color: '#059669',
                    description: 'Expansion cohort for biomarker validation.'
                }
            ],
            connections: [
                {
                    id: 'conn-1',
                    fromNodeId: 'coh-1',
                    fromPort: 'right',
                    toNodeId: 'dep-1',
                    toPort: 'left'
                },
                {
                    id: 'conn-2',
                    fromNodeId: 'dep-1',
                    fromPort: 'right',
                    toNodeId: 'coh-2',
                    toPort: 'left'
                },
                {
                    id: 'conn-3',
                    fromNodeId: 'coh-2',
                    fromPort: 'right',
                    toNodeId: 'dep-2',
                    toPort: 'left'
                },
                {
                    id: 'conn-4',
                    fromNodeId: 'dep-2',
                    fromPort: 'right',
                    toNodeId: 'coh-3',
                    toPort: 'left'
                }
            ]
        }
    },
    {
        id: 'parallel_randomized',
        name: 'Parallel Randomized Arms',
        description: 'Screening into 1:1 randomized allocation with washout delay.',
        flow: {
            version: '1.0.0',
            nodes: [
                {
                    id: 'coh-screen',
                    type: 'cohort',
                    x: 60,
                    y: 200,
                    name: 'Screening',
                    subjects: 50,
                    color: '#64748b',
                    description: 'Baseline randomized subjects pool.'
                },
                {
                    id: 'dep-rand',
                    type: 'dependency',
                    x: 280,
                    y: 204,
                    name: 'Randomization',
                    days: 7,
                    icon: 'clock',
                    color: '#000000'
                },
                {
                    id: 'coh-arm1',
                    type: 'cohort',
                    x: 420,
                    y: 120,
                    name: 'Treatment Arm A',
                    subjects: 25,
                    color: '#0284c7'
                },
                {
                    id: 'coh-arm2',
                    type: 'cohort',
                    x: 420,
                    y: 280,
                    name: 'Control Arm B',
                    subjects: 25,
                    color: '#7c3aed'
                }
            ],
            connections: [
                {
                    id: 'conn-r1',
                    fromNodeId: 'coh-screen',
                    fromPort: 'right',
                    toNodeId: 'dep-rand',
                    toPort: 'left'
                },
                {
                    id: 'conn-r2',
                    fromNodeId: 'dep-rand',
                    fromPort: 'right',
                    toNodeId: 'coh-arm1',
                    toPort: 'left',
                    label: '1:1'
                },
                {
                    id: 'conn-r3',
                    fromNodeId: 'dep-rand',
                    fromPort: 'right',
                    toNodeId: 'coh-arm2',
                    toPort: 'left',
                    label: '1:1'
                }
            ]
        }
    }
];

/*
 * Public API Surface of ngx-cohort-designer
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CLINICAL_ICONS, COHORT_EXPANDED_HEIGHT, COHORT_EXPANDED_WIDTH, COHORT_HEIGHT, COHORT_WIDTH, CohortDesignerComponent, CohortDesignerService, CohortNodeComponent, DEPENDENCY_HEIGHT, DEPENDENCY_WIDTH, DependencyNodeComponent, InspectorPanelComponent, PROTOCOL_TEMPLATES, ToolbarComponent };
//# sourceMappingURL=ngx-cohort-designer.mjs.map
