import { EventEmitter } from '@angular/core';
import { CohortNode, PortPosition } from '../../models/cohort-designer.model';
import * as i0 from "@angular/core";
export declare class CohortNodeComponent {
    private service;
    node: CohortNode;
    isSelected: boolean;
    readonly: boolean;
    selectNode: EventEmitter<string>;
    portClick: EventEmitter<{
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }>;
    portMouseUp: EventEmitter<{
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }>;
    deleteNode: EventEmitter<string>;
    resizeStart: EventEmitter<{
        nodeId: string;
        side: "right" | "left" | "bottom" | "corner";
        event: MouseEvent;
    }>;
    isHovered: boolean;
    get cardWidth(): number;
    get cardHeight(): number;
    readonly activeConnecting: import("@angular/core").WritableSignal<import("ngx-cohort-designer").ActiveConnectingState | null>;
    readonly isConnectingActive: import("@angular/core").Signal<boolean>;
    readonly isSourceOfConnection: import("@angular/core").Signal<boolean>;
    readonly isValidConnectionTarget: import("@angular/core").Signal<boolean>;
    readonly ports: PortPosition[];
    onCardClick(event: MouseEvent): void;
    onResizeMouseDown(side: 'right' | 'left' | 'bottom' | 'corner', event: MouseEvent): void;
    toggleExpand(event: MouseEvent): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onPortMouseDown(port: PortPosition, event: MouseEvent): void;
    onPortMouseUp(port: PortPosition, event: MouseEvent): void;
    onPortMouseEnter(port: PortPosition): void;
    onPortMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CohortNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CohortNodeComponent, "lib-cohort-node", never, { "node": { "alias": "node"; "required": true; }; "isSelected": { "alias": "isSelected"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, { "selectNode": "selectNode"; "portClick": "portClick"; "portMouseUp": "portMouseUp"; "deleteNode": "deleteNode"; "resizeStart": "resizeStart"; }, never, never, true, never>;
}
