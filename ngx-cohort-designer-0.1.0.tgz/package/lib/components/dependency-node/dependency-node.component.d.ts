import { EventEmitter } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { DependencyNode, PortPosition, IconOption } from '../../models/cohort-designer.model';
import * as i0 from "@angular/core";
export declare class DependencyNodeComponent {
    private service;
    private sanitizer;
    node: DependencyNode;
    isSelected: boolean;
    readonly: boolean;
    customIcons: IconOption[];
    selectNode: EventEmitter<string>;
    portClick: EventEmitter<{
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }>;
    portMouseUp: EventEmitter<{
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }>;
    deleteNode: EventEmitter<string>;
    readonly activeConnecting: import("@angular/core").WritableSignal<import("ngx-cohort-designer").ActiveConnectingState | null>;
    readonly isConnectingActive: import("@angular/core").Signal<boolean>;
    readonly isSourceOfConnection: import("@angular/core").Signal<boolean>;
    readonly isValidConnectionTarget: import("@angular/core").Signal<boolean>;
    readonly ports: PortPosition[];
    readonly iconSvg: import("@angular/core").Signal<SafeHtml>;
    onNodeClick(event: MouseEvent): void;
    onPortMouseDown(port: PortPosition, event: MouseEvent): void;
    onPortMouseUp(port: PortPosition, event: MouseEvent): void;
    onPortMouseEnter(port: PortPosition): void;
    onPortMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DependencyNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DependencyNodeComponent, "lib-dependency-node", never, { "node": { "alias": "node"; "required": true; }; "isSelected": { "alias": "isSelected"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "customIcons": { "alias": "customIcons"; "required": false; }; }, { "selectNode": "selectNode"; "portClick": "portClick"; "portMouseUp": "portMouseUp"; "deleteNode": "deleteNode"; }, never, never, true, never>;
}
