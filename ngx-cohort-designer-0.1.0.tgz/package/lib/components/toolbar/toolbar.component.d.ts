import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ToolbarComponent {
    readonly: boolean;
    addCohort: EventEmitter<void>;
    addDependency: EventEmitter<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarComponent, "lib-toolbar", never, { "readonly": { "alias": "readonly"; "required": false; }; }, { "addCohort": "addCohort"; "addDependency": "addDependency"; }, never, never, true, never>;
}
