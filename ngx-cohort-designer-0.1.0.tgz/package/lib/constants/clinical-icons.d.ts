import { IconOption } from '../models/cohort-designer.model';
export declare const CLINICAL_ICONS: IconOption[];
