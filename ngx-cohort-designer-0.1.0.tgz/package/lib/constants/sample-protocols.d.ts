import { CohortDesignFlow } from '../models/cohort-designer.model';
export interface ProtocolTemplate {
    id: string;
    name: string;
    description: string;
    flow: CohortDesignFlow;
}
export declare const PROTOCOL_TEMPLATES: ProtocolTemplate[];
