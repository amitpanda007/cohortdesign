export type PortPosition = 'left' | 'right';
export interface BaseNode {
    id: string;
    type: 'cohort' | 'dependency';
    x: number;
    y: number;
}
export interface CohortNode extends BaseNode {
    type: 'cohort';
    name: string;
    subjects: number;
    cohortLevel?: 'Country' | 'Worldwide';
    randomizationTarget?: number;
    targetLastSubjectRandomized?: string;
    screeningPeriod?: number;
    color: string;
    description?: string;
    width?: number;
    height?: number;
    isExpanded?: boolean;
}
export interface DependencyNode extends BaseNode {
    type: 'dependency';
    name: string;
    days: number;
    event?: 'Number of Subjects' | 'Enrollment Complete';
    eventSubjectCount?: number;
    precedingCohortIds?: string[];
    dependentCohortIds?: string[];
    icon: string;
    customSvg?: string;
    color?: string;
    description?: string;
}
export type FlowNode = CohortNode | DependencyNode;
export interface Connection {
    id: string;
    fromNodeId: string;
    fromPort: PortPosition;
    toNodeId: string;
    toPort: PortPosition;
    label?: string;
    color?: string;
}
export interface CohortDesignFlow {
    version?: string;
    nodes: FlowNode[];
    connections: Connection[];
}
export interface IconOption {
    id: string;
    name: string;
    svgPath: string;
    viewBox?: string;
}
export interface ActiveConnectingState {
    fromNodeId: string;
    fromPort: PortPosition;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
}
export interface CanvasViewTransform {
    zoom: number;
    panX: number;
    panY: number;
}
