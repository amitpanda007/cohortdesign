import { EventEmitter, OnInit, OnChanges, SimpleChanges, ElementRef } from '@angular/core';
import { CohortDesignFlow, FlowNode, CohortNode, DependencyNode, Connection, PortPosition, IconOption } from './models/cohort-designer.model';
import { CohortDesignerService } from './services/cohort-designer.service';
import * as i0 from "@angular/core";
export declare class CohortDesignerComponent implements OnInit, OnChanges {
    readonly service: CohortDesignerService;
    flowData?: CohortDesignFlow;
    readonly: boolean;
    customIcons: IconOption[];
    flowChange: EventEmitter<CohortDesignFlow>;
    save: EventEmitter<CohortDesignFlow>;
    nodeSelected: EventEmitter<FlowNode | null>;
    connectionSelected: EventEmitter<Connection | null>;
    canvasContainer: ElementRef<HTMLDivElement>;
    readonly nodes: import("@angular/core").WritableSignal<FlowNode[]>;
    readonly connections: import("@angular/core").WritableSignal<Connection[]>;
    readonly selectedNode: import("@angular/core").Signal<FlowNode | null>;
    readonly selectedConnection: import("@angular/core").Signal<Connection | null>;
    readonly activeConnecting: import("@angular/core").WritableSignal<import("ngx-cohort-designer").ActiveConnectingState | null>;
    readonly transform: import("@angular/core").WritableSignal<import("ngx-cohort-designer").CanvasViewTransform>;
    isDraggingNode: boolean;
    draggedNodeId: string | null;
    dragNodeOffset: {
        x: number;
        y: number;
    };
    isResizing: boolean;
    private resizeState;
    isPanningCanvas: boolean;
    panStart: {
        x: number;
        y: number;
    };
    panInitial: {
        x: number;
        y: number;
    };
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    getData(): CohortDesignFlow;
    saveData(): CohortDesignFlow;
    loadData(flow: CohortDesignFlow): void;
    clear(): void;
    addCohort(nameOrX?: string | number, subjectsOrY?: number, data?: Partial<CohortNode>): CohortNode;
    addCohortByName(name: string, data?: Partial<CohortNode>): CohortNode;
    addCohorts(items: (string | Partial<CohortNode>)[]): CohortNode[];
    addDependency(x?: number, y?: number, customDataOrIcon?: Partial<DependencyNode> | string): DependencyNode;
    getCanvasCoordinates(clientX: number, clientY: number): {
        x: number;
        y: number;
    };
    getConnectionPath(conn: Connection): string;
    getConnectionMidpoint(conn: Connection): {
        x: number;
        y: number;
    };
    getActiveConnectingPath(): string;
    onCohortResizeStart(data: {
        nodeId: string;
        side: 'right' | 'left' | 'bottom' | 'corner';
        event: MouseEvent;
    }): void;
    onNodeMouseDown(node: FlowNode, event: MouseEvent): void;
    onCanvasMouseDown(event: MouseEvent): void;
    onWindowMouseMove(event: MouseEvent): void;
    onWindowMouseUp(event: MouseEvent): void;
    onCanvasWheel(event: WheelEvent): void;
    onKeyDown(event: KeyboardEvent): void;
    onPortClick(data: {
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }): void;
    onPortMouseUp(data: {
        nodeId: string;
        port: PortPosition;
        event: MouseEvent;
    }): void;
    onSelectNode(nodeId: string): void;
    onSelectConnection(connId: string, event: MouseEvent): void;
    onCloseInspector(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CohortDesignerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CohortDesignerComponent, "ngx-cohort-designer", never, { "flowData": { "alias": "flowData"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "customIcons": { "alias": "customIcons"; "required": false; }; }, { "flowChange": "flowChange"; "save": "save"; "nodeSelected": "nodeSelected"; "connectionSelected": "connectionSelected"; }, never, never, true, never>;
}
