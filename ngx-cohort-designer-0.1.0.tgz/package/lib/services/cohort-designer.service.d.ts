import { FlowNode, CohortNode, DependencyNode, Connection, CohortDesignFlow, PortPosition, ActiveConnectingState, CanvasViewTransform } from '../models/cohort-designer.model';
import * as i0 from "@angular/core";
export declare const COHORT_WIDTH = 180;
export declare const COHORT_EXPANDED_WIDTH = 280;
export declare const COHORT_HEIGHT = 50;
export declare const COHORT_EXPANDED_HEIGHT = 54;
export declare const DEPENDENCY_WIDTH = 46;
export declare const DEPENDENCY_HEIGHT = 46;
export declare class CohortDesignerService {
    readonly nodes: import("@angular/core").WritableSignal<FlowNode[]>;
    readonly connections: import("@angular/core").WritableSignal<Connection[]>;
    readonly selectedNodeId: import("@angular/core").WritableSignal<string | null>;
    readonly selectedConnectionId: import("@angular/core").WritableSignal<string | null>;
    readonly activeConnecting: import("@angular/core").WritableSignal<ActiveConnectingState | null>;
    readonly transform: import("@angular/core").WritableSignal<CanvasViewTransform>;
    readonly hoveredPort: import("@angular/core").WritableSignal<{
        nodeId: string;
        port: PortPosition;
    } | null>;
    readonly isRightPanelOpen: import("@angular/core").WritableSignal<boolean>;
    readonly rightPanelTab: import("@angular/core").WritableSignal<"overview" | "details">;
    readonly allBlocksSection: import("@angular/core").WritableSignal<"cohorts" | "dependencies">;
    readonly selectedNode: import("@angular/core").Signal<FlowNode | null>;
    readonly selectedConnection: import("@angular/core").Signal<Connection | null>;
    readonly cohortNodes: import("@angular/core").Signal<CohortNode[]>;
    readonly dependencyNodes: import("@angular/core").Signal<DependencyNode[]>;
    getPortCoordinates(nodeId: string, port: PortPosition): {
        x: number;
        y: number;
    };
    calculateBezierPath(x1: number, y1: number, fromPort: PortPosition, x2: number, y2: number, toPort: PortPosition): string;
    /**
     * Check if a directed path already exists from startNodeId to targetNodeId.
     */
    hasPath(startNodeId: string, targetNodeId: string): boolean;
    /**
     * Validate if toNodeId is an allowable target for the active connection.
     * Rules:
     * 1. Cannot connect Cohort directly to Cohort (must have a dependency in between).
     * 2. Cannot connect Dependency directly to Dependency.
     * 3. Cannot connect a node to itself.
     * 4. Cannot create circular dependencies (cycles).
     */
    isValidTarget(toNodeId: string): boolean;
    addCohort(nameOrX?: string | number, subjectsOrY?: number, customData?: Partial<CohortNode>): CohortNode;
    addCohortByName(name: string, data?: Partial<CohortNode>): CohortNode;
    addCohorts(items: (string | Partial<CohortNode>)[]): CohortNode[];
    toggleCohortExpand(nodeId: string): void;
    updateNodeDimensions(id: string, width: number, height: number, x?: number, y?: number): void;
    resetCohortDimensions(id: string): void;
    addDependency(x?: number, y?: number, customDataOrIcon?: Partial<DependencyNode> | string): DependencyNode;
    addConnection(fromNodeId: string, fromPort: PortPosition, toNodeId: string, toPort: PortPosition, label?: string): boolean;
    isCohortPreceding(dependencyId: string, cohortId: string): boolean;
    togglePrecedingCohort(dependencyId: string, cohortId: string): void;
    isCohortDependent(dependencyId: string, cohortId: string): boolean;
    toggleDependentCohort(dependencyId: string, cohortId: string): void;
    updateNodePosition(id: string, x: number, y: number): void;
    updateNodeData(id: string, updates: Partial<FlowNode>): void;
    deleteNode(id: string): void;
    startConnection(nodeId: string, port: PortPosition, canvasX: number, canvasY: number): void;
    updateConnectingPosition(canvasX: number, canvasY: number): void;
    completeConnection(toNodeId: string, toPort: PortPosition): boolean;
    cancelConnection(): void;
    deleteConnection(id: string): void;
    updateConnection(id: string, updates: Partial<Connection>): void;
    selectNode(id: string | null): void;
    selectConnection(id: string | null): void;
    openOverviewPanel(): void;
    setAllBlocksSection(section: 'cohorts' | 'dependencies'): void;
    toggleRightPanel(): void;
    clearSelection(): void;
    setTransform(zoom: number, panX: number, panY: number): void;
    zoomBy(delta: number): void;
    resetView(): void;
    getData(): CohortDesignFlow;
    save(): CohortDesignFlow;
    loadFlow(flow: CohortDesignFlow): void;
    clearAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CohortDesignerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CohortDesignerService>;
}
